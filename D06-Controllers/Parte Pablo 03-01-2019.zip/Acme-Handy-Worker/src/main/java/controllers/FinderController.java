
package controllers;

import java.util.Collection;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.FinderService;
import domain.Finder;
import domain.FixUpTask;

@Controller
@RequestMapping("/finder/handyworker")
public class FinderController extends AbstractController {

	//Managed services

	@Autowired
	private FinderService	finderService;


	//Constructors
	public FinderController() {
		super();
	}

	//R11.2 Search Fix-Up Tasks by params

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		Finder finder;

		finder = this.finderService.findFinderByPrincipal();
		Assert.notNull(finder);
		result = this.createEditModelAndView(finder);

		return result;
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Finder finder, final BindingResult binding) {
		ModelAndView result;
		Collection<FixUpTask> fixUpTasks;

		if (binding.hasErrors())
			result = this.createEditModelAndView(finder);
		else
			try {
				fixUpTasks = this.finderService.findTasksByParams(finder);
				finder.setLastUpdate(new Date());
				finder.setFixUpTasks(fixUpTasks);
				this.finderService.save(finder);
				result = new ModelAndView("fixUpTask/fixUpTasksList");
				fixUpTasks = this.finderService.findTasksByParams(finder);
				result.addObject("fixUpTasks", fixUpTasks);
				result.addObject("requestURI", "finder/handyworker/searchPost.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(finder, "finder.commit.error");
			}

		return result;
	}
	@RequestMapping(value = "/showStored", method = RequestMethod.GET)
	public ModelAndView viewStored() {
		ModelAndView result;
		Finder finder;
		Collection<FixUpTask> fixUpTasks;

		finder = this.finderService.findFinderByPrincipal();
		result = new ModelAndView("fixUpTask/fixUpTasksList");

		fixUpTasks = finder.getFixUpTasks();
		if (!this.finderService.checkInCache(finder)) {
			fixUpTasks.clear();
			result = this.createEditModelAndView(finder, "finder.error");
		}
		result.addObject("fixUpTasks", fixUpTasks);
		result.addObject("requestURI", "finder/handyworker/showStored.do");
		return result;
	}
	// Ancillary methods 

	protected ModelAndView createEditModelAndView(final Finder finder) {
		ModelAndView result;

		result = this.createEditModelAndView(finder, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Finder finder, final String message) {
		ModelAndView result;
		Collection<FixUpTask> fixUpTasks;

		fixUpTasks = this.finderService.findTasksByParams(finder);
		result = new ModelAndView("finder/searchForm");
		result.addObject("finder", finder);
		result.addObject("fixUpTasks", fixUpTasks);
		result.addObject("message", message);

		return result;
	}
}
