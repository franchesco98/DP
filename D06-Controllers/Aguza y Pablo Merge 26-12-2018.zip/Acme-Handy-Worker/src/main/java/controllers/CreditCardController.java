/*
 * CustomerController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ApplicationService;
import services.CategoryService;
import services.ConfigurationService;
import services.CreditCardService;
import services.CustomerService;
import services.FixUpTaskService;
import services.WarrantyService;
import domain.Application;
import domain.CreditCard;

@Controller
@RequestMapping("creditCard/customer")
public class CreditCardController extends AbstractController {

	//Managed services
	@Autowired
	private ApplicationService		applicationService;
	@Autowired
	private CustomerService			customerService;
	@Autowired
	private WarrantyService			warrantyService;
	@Autowired
	private CategoryService			categoryService;
	@Autowired
	private FixUpTaskService		fixUpTaskService;
	@Autowired
	private ConfigurationService	configurationService;
	@Autowired
	private CreditCardService		creditCardService;


	// Constructors -----------------------------------------------------------

	public CreditCardController() {
		super();
	}

	//list-------------------------------------------------------------------

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int applicationId) {

		final ModelAndView result;
		Collection<CreditCard> creditCards;
		final Application application = this.applicationService.findOne(applicationId);

		creditCards = this.creditCardService.getCreditCardsByPrincipal();

		if (creditCards == null)
			creditCards = new ArrayList<>();

		result = new ModelAndView("creditCard/payingApplication");
		result.addObject("creditCards", creditCards);
		result.addObject("application", application);
		result.addObject("requestURI", "creditCard/customer/list.do");

		return result;
	}

}
