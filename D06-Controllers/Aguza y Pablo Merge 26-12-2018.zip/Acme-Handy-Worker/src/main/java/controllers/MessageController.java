/*
 * BoxController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.BoxService;
import services.MessageService;
import domain.Actor;
import domain.Box;
import domain.Message;

@Controller
@RequestMapping("/message")
public class MessageController extends AbstractController {

	//Managed services
	@Autowired
	private MessageService			messageService;
	
	@Autowired
	private BoxService				boxService;

	@Autowired
	private ActorService			actorService;



	// Constructors -----------------------------------------------------------

	public MessageController() {
		super();
	}

	// List ---------------------------------------------------------------		

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam int boxId) {
		ModelAndView result;
		Collection<Message> messages = null;


		Box box = this.boxService.findOne(boxId);
		messages = box.getMessages();
		

		result = new ModelAndView("message/messageList");
		

		result.addObject("messagesToList", messages);
		result.addObject("box", box);
		
		result.addObject("requestURI", "message/list.do");

		return result;
	}

	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		final ModelAndView result;
		Message message;

		message = this.messageService.create();
		result = this.createEditModelAndView(message);
		

		
		result.addObject("toShow", false);
		
		return result;
	}

	// Edit: En este caso el metodo edit solo se usaria para VER mensajes, ya que no se pueden editar ---------------------------------------------------------------		

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int boxId, @RequestParam int messageId) {
		final ModelAndView result;
		Box box;
		Message messageToShow;

		box = this.boxService.findOne(boxId);
		Assert.notNull(box);
		messageToShow = this.messageService.findOne(messageId);
		Assert.notNull(messageToShow);
		
		result = this.createEditModelAndView(messageToShow);
		
		Collection<String> priority= new ArrayList<>();
		priority.add(messageToShow.getPriority());
		result.addObject("box", box);
		result.addObject("toShow", true);
		result.addObject("actors", messageToShow.getRecipients());
		result.addObject("priorities", priority);
		
		return result;
	}
	
	// Save ---------------------------------------------------------------		
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params="save")
	public ModelAndView save(@Valid Message messageToSave, BindingResult binding) {
		ModelAndView result;
		
		System.out.println(binding.getAllErrors());
		
		System.out.println(messageToSave.getFlagSpam());
		System.out.println(messageToSave.getPriority());
		
		if(binding.hasErrors()){
			result = createEditModelAndView(messageToSave);
		}else{
			try{
				//Para implementar la funcionalidad para enviar un mensaje a todos los actores, se usa temporalmente el atributo flagSpam para ver si el sender lo ha seleccionado o no, despues le asignamos el valor por defecto a flagSpam, y ya en el servicio de message, al guardarlo, se le dara su valor apropiado
				if(messageToSave.getFlagSpam()){
					Collection<Actor> allActors = this.actorService.findAll();
					allActors.remove(messageToSave.getSender());
					messageToSave.setRecipients(allActors);
					messageToSave.setFlagSpam(false);
				}
				Box outBox = this.messageService.save(messageToSave);
				
				//Nos llevara a la outbox del sender
				String redirect = "redirect:list.do?boxId=" + outBox.getId();
				result = new ModelAndView(redirect);
			}catch(Throwable oops){
				
				System.out.println(oops.getMessage());
				System.out.println(oops.getStackTrace());
				
				result = createEditModelAndView(messageToSave, "message.commit.error");
			}
		}
		
		return result;
	}
	

	// Ancillary Methods -----------------------------------------------------
	protected ModelAndView createEditModelAndView(final Message message) {
		ModelAndView result;

		result = this.createEditModelAndView(message, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Message messageToCreate, final String messageCode) {
		ModelAndView result;
		result = new ModelAndView("message/create");
		
		//Posibles recipients del message (todos los actores menos el que lo envia)
		Collection<Actor> actors = this.actorService.findAll();
		Actor logedActor = this.actorService.findActorByPrincipal();
		actors.remove(logedActor);
		
		//Posibles priorities
		Collection<String> priorities= new ArrayList<>();
		priorities.add("HIGH");
		priorities.add("NEUTRAL");
		priorities.add("LOW");
		
		result.addObject("priorities", priorities);		
		result.addObject("actors", actors);		
		result.addObject("messageToCreate", messageToCreate);
		result.addObject("message",messageCode);
		
		return result;
	}
}
