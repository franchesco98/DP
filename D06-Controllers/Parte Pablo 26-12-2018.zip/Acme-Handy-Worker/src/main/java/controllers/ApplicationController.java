
package controllers;

import java.text.DecimalFormat;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ApplicationService;
import services.ConfigurationService;
import services.FixUpTaskService;
import domain.Application;
import domain.Configuration;
import domain.FixUpTask;

@Controller
@RequestMapping("/application/handyworker")
public class ApplicationController extends AbstractController {

	//Managed services
	@Autowired
	private ApplicationService		applicationService;
	@Autowired
	private FixUpTaskService		fixUpTaskService;
	@Autowired
	private ConfigurationService	configurationService;


	//Constructors
	public ApplicationController() {
		super();
	}

	//Listing
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		final Collection<Application> applications;
		Configuration configuration;
		final DecimalFormat df = new DecimalFormat("#.##");

		applications = this.applicationService.findApplicationsOfHW();
		configuration = (Configuration) this.configurationService.findAll().toArray()[0];

		result = new ModelAndView("application/ApplicationList");
		result.addObject("applications", applications);
		result.addObject("requestURI", "application/handyworker/list.do");
		return result;

	}

	//Creation
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int fixUpTaskId) {
		final ModelAndView result;
		Application application;
		FixUpTask fixUpTask;

		fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);
		application = this.applicationService.create();
		application.setFixUpTask(fixUpTask);

		result = this.createEditModelAndView(application);
		result.addObject("toShow", false);
		return result;

	}

	// Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int applicationId) {
		ModelAndView result;
		Application application;

		application = this.applicationService.findOne(applicationId);
		Assert.notNull(application);
		result = this.createEditModelAndView(application);
		result.addObject("toShow", true);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Application application, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(application);
		else
			try {
				this.applicationService.save(application);
				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(application, "application.commit.error");
			}

		return result;
	}

	//Delete
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Application application, final BindingResult binding) {
		ModelAndView result;

		try {
			this.applicationService.delete(application);
			result = new ModelAndView("redirect:list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(application, "application.commit.error");
		}

		return result;
	}

	// Ancillary methods 

	protected ModelAndView createEditModelAndView(final Application application) {
		ModelAndView result;

		result = this.createEditModelAndView(application, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Application application, final String message) {
		ModelAndView result;
		Collection<FixUpTask> fixUpTasks;

		fixUpTasks = this.fixUpTaskService.findAll();

		result = new ModelAndView("application/edit");
		result.addObject("application", application);
		result.addObject("fixUpTasks", fixUpTasks);
		result.addObject("message", message);

		return result;
	}

}
