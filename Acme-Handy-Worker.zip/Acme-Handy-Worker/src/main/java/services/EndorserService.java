/*
 * ActorService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.EndorserRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Configuration;
import domain.Customer;
import domain.Endorsement;
import domain.Endorser;
import domain.HandyWorker;

@Service
@Transactional
public class EndorserService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private EndorserRepository		endorserRepository;
	@Autowired
	private EndorsementService		endorsementService;
	@Autowired
	private AdministratorService	administratorService;
	@Autowired
	private CustomerService			customerService;
	@Autowired
	private HandyWorkerService		handyWorkerService;
	@Autowired
	private BoxService				boxService;
	@Autowired
	private ConfigurationService	configurationService;


	// Supporting services ----------------------------------------------------

	// Constructors -----------------------------------------------------------

	public EndorserService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Collection<Endorser> findAll() {
		Collection<Endorser> result;

		result = this.endorserRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Actor findOne(final int endorserId) {
		Assert.isTrue(endorserId != 0);

		Actor result;

		result = this.endorserRepository.findOne(endorserId);
		Assert.notNull(result);

		return result;
	}

	public Actor save(final Endorser endorser) {
		Assert.notNull(endorser);
		Assert.notNull(endorser.getUserAccount().getUsername());
		Assert.notNull(endorser.getUserAccount().getPassword());

		//comprobamos que no nos han dado cadenas vacias en los at opcionales
		if (endorser.getMiddleName() != null)
			Assert.isTrue(!(endorser.getMiddleName().trim().equals("")));

		if (endorser.getAddress() != null)
			Assert.isTrue(!(endorser.getAddress().trim().equals("")));

		Endorser result;

		if (endorser.getId() == 0) {

			endorser.setBoxes(this.boxService.originalBoxes());
			endorser.getUserAccount().setAccountNonLocked(true);
			endorser.setIsSuspicious(false);

			endorser.setScore(0.0);
			result = this.endorserRepository.save(endorser);
		} else
			result = this.endorserRepository.save(endorser);

		return result;
	}

	public void delete(final Endorser endorser) {
		Assert.notNull(endorser);
		Assert.isTrue(endorser.getId() != 0);
		Assert.isTrue(this.endorserRepository.exists(endorser.getId()));
		//comprobar que el endorser no tenga endorsement
		Assert.isTrue(this.endorserRepository.findEndorsementsByEndorserId(endorser.getId()).size() == 0);

		this.endorserRepository.delete(endorser);
	}

	// Other business methods -------------------------------------------------
	public Endorser findEndorserByPrincipal() {
		Endorser result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.endorserByUserAccount(userAccount);
		Assert.notNull(result);

		return result;
	}

	public Endorser endorserByUserAccount(final UserAccount userAccount) {
		Assert.notNull(userAccount);

		Endorser result;

		result = this.endorserRepository.findByUserAccountId(userAccount.getId());

		return result;
	}

	public Endorsement createAndUpdateEndorsemet(final Endorsement endorsement) {
		Assert.notNull(endorsement);

		//TODO: Comprobar que si el sender es un customer, el recipient tiene que ser hw y viceversa

		if (endorsement.getId() == 0)
			endorsement.setMoment(new Date());

		this.endorsementService.save(endorsement);
		return endorsement;

	}

	public Collection<Endorsement> principalEndorsementsSent() {
		return this.endorserRepository.findEndorsementsSentByEndorserId(this.findEndorserByPrincipal().getId());
	}

	public Collection<Endorsement> principalEndorsementsReceived() {
		return this.endorserRepository.findEndorsementsRecipientByEndorserId(this.findEndorserByPrincipal().getId());
	}

	public void deleteEndorsement(final Endorsement endorsement) {

		Assert.notNull(endorsement);

		final Endorser loggedEndorser = this.findEndorserByPrincipal();
		Assert.isTrue((loggedEndorser.getId() == endorsement.getRecipient().getId()) || (loggedEndorser.getId() == endorsement.getSender().getId()));

		this.endorsementService.delete(endorsement);

	}

	public Collection<Endorsement> findEndorsementsRecipientByEndorserId(final Endorser endorser) {
		Assert.notNull(endorser);

		return this.endorserRepository.findEndorsementsRecipientByEndorserId(endorser.getId());
	}

	public Collection<Customer> findRelatedCustomers(final HandyWorker handyWorker) {
		return this.endorserRepository.findRelatedCustomersByHandyWorkerId(handyWorker.getId());
	}

	public Collection<HandyWorker> findRelatedHandyWorkers(final Customer customer) {
		return this.endorserRepository.findRelatedHandyWorkersByCustomerId(customer.getId());
	}
	//R50.1

	//sumo positivas-negativas/total

	public void computedScore() {

		//ver que el principal sea un admin
		this.administratorService.checkPrincipalIsAdmin();

		//cogemos las palabras positivas y negativas en ambos idiomas
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);
		final String[] positiveWordsE = configuration.getPositiveWordsE().split(",");
		final String[] negativeWordsE = configuration.getNegativeWordsE().split(",");
		final String[] positiveWordsS = configuration.getPositiveWordsS().split(",");
		final String[] negativeWordsS = configuration.getNegativeWordsS().split(",");

		final Collection<Endorser> allEndorsers = this.findAll();

		for (final Endorser endorser : allEndorsers) {

			final Collection<Endorsement> endorsementsRecived = this.findEndorsementsRecipientByEndorserId(endorser);

			if (endorsementsRecived.size() != 0) {

				Double countPositiveWordE = 0.0;
				Double countNegativeWordE = 0.0;
				Double countPositiveWordsS = 0.0;
				Double countNegativeWordsS = 0.0;

				for (final Endorsement endorsement : endorsementsRecived) {
					//comentarios de un endorsement
					final String comment = endorsement.getComments().toLowerCase();

					//compruebo las negative/positive words
					for (final String positiveWordE : positiveWordsE)
						if (comment.contains(positiveWordE.trim().toLowerCase()))
							countPositiveWordE++;
					for (final String negativeWordE : negativeWordsE)
						if (comment.contains(negativeWordE.trim().toLowerCase()))
							countNegativeWordE++;
					for (final String positiveWordS : positiveWordsS)
						if (comment.contains(positiveWordS.trim().toLowerCase()))
							countPositiveWordsS++;
					for (final String negativeWordS : negativeWordsS)
						if (comment.contains(negativeWordS.trim().toLowerCase()))
							countNegativeWordsS++;

				}
				if (countPositiveWordE != 0 || countNegativeWordE != 0 || countPositiveWordsS != 0 || countNegativeWordsS != 0) {
					final Double score = ((countPositiveWordE + countPositiveWordsS) - (countNegativeWordE + countNegativeWordsS)) / (countPositiveWordE + countPositiveWordsS + countNegativeWordE + countNegativeWordsS);
					endorser.setScore(score);
					this.save(endorser);
				}
			}
		}

	}
}
