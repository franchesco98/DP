
package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ConfigurationRepository;
import repositories.FinderRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import domain.Configuration;
import domain.Finder;
import domain.FixUpTask;

@Service
@Transactional
public class FinderService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private FinderRepository		finderRepository;
	@Autowired
	private ConfigurationRepository	configurationRepository;


	// Constructors -----------------------------------------------------------

	public FinderService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Finder create() {
		Finder result;

		result = new Finder();

		return result;
	}

	public Collection<Finder> findAll() {
		Collection<Finder> result;

		result = this.finderRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Finder findOne(final int finderId) {
		Finder result;

		result = this.finderRepository.findOne(finderId);
		Assert.notNull(result);

		return result;
	}

	public Finder save(final Finder finder) {
		Assert.notNull(finder);

		Finder result;

		result = this.finderRepository.save(finder);

		return result;
	}

	public void delete(final Finder finder) {
		Assert.notNull(finder);
		Assert.isTrue(finder.getId() != 0);

		this.finderRepository.delete(finder);
	}

	//Other businnes methods

	public Collection<FixUpTask> findTasksByParams(final Finder finder) {
		final Collection<FixUpTask> f;
		final Configuration configuration;
		Pageable pageable;

		configuration = (Configuration) this.configurationRepository.findAll().toArray()[0];
		final int numberOfResults = configuration.getNumberOfResult();
		pageable = new PageRequest(0, numberOfResults);

		if (finder.getPriceMin() == null && finder.getPriceMax() == null && finder.getDateMin() == null && finder.getDateMax() == null)
			f = this.finderRepository.findTasksByParamsWithoutPriceAndDate(finder.getKeyWord(), finder.getCategory(), finder.getWarranty(), pageable);
		else if (finder.getDateMin() == null && finder.getDateMax() == null)
			f = this.finderRepository.findTasksByParamsWithoutDate(finder.getKeyWord(), finder.getCategory(), finder.getWarranty(), finder.getPriceMin(), finder.getPriceMax(), pageable);
		else if (finder.getPriceMin() == null && finder.getPriceMax() == null)
			f = this.finderRepository.findTasksByParamsWithoutPrice(finder.getKeyWord(), finder.getCategory(), finder.getWarranty(), finder.getDateMin(), finder.getDateMax(), pageable);
		else
			f = this.finderRepository.findTasksByParams(finder.getKeyWord(), finder.getCategory(), finder.getWarranty(), finder.getPriceMin(), finder.getPriceMax(), finder.getDateMin(), finder.getDateMax(), pageable);
		return f;

	}

	public Finder findFinderByPrincipal() {

		Finder result;
		final UserAccount user = LoginService.getPrincipal();
		final Integer userID = user.getId();
		final Authority handyWorkerAuthority = new Authority();
		handyWorkerAuthority.setAuthority(Authority.HANDYWORKER);
		Assert.isTrue(user.getAuthorities().contains(handyWorkerAuthority));

		result = this.finderRepository.findFinderByPrincipal(userID);

		return result;
	}

	public Boolean checkInCache(final Finder finder) {

		boolean result = false;

		final Date finderCache = finder.getLastUpdate();
		final Date currentDate = new Date();
		final double difference = Math.floor(currentDate.getTime() - finderCache.getTime()) / (60 * 60 * 1000);
		final Configuration configuration = (Configuration) this.configurationRepository.findAll().toArray()[0];
		final int limit = configuration.getFinderCacheTime();

		if (difference < limit)
			result = true;

		return result;
	}

	public Finder originalFinder() {
		Finder saved;

		final Finder finder = this.create();
		saved = this.save(finder);

		return saved;
	}

}
