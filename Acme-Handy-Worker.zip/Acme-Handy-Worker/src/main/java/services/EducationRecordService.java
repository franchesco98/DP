
package services;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.EducationRecordRepository;
import domain.Curriculum;
import domain.EducationRecord;
import domain.HandyWorker;

@Service
@Transactional
public class EducationRecordService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private EducationRecordRepository	educationRecordRepository;
	@Autowired
	private HandyWorkerService			handyWorkerService;
	@Autowired
	private CurriculumService			curriculumService;


	// Constructors -----------------------------------------------------------

	public EducationRecordService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public EducationRecord create() {
		EducationRecord result;

		result = new EducationRecord();

		return result;
	}

	public Collection<EducationRecord> findAll() {
		Collection<EducationRecord> result;

		result = this.educationRecordRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public EducationRecord findOne(final int educationRecordId) {
		EducationRecord result;

		result = this.educationRecordRepository.findOne(educationRecordId);
		Assert.notNull(result);

		return result;
	}

	public EducationRecord save(final EducationRecord educationRecord) {
		Assert.notNull(educationRecord);

		EducationRecord result;

		HandyWorker handyWorker;
		Curriculum curriculum;

		handyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();
		curriculum = handyWorker.getCurriculum();
		final Collection<EducationRecord> curriculums = new HashSet<>(curriculum.getEducationRecords());

		curriculums.add(educationRecord);
		curriculum.setEducationRecords(curriculums);
		result = this.educationRecordRepository.save(educationRecord);
		this.curriculumService.save(curriculum);
		return result;
	}

	public void delete(final EducationRecord educationRecord) {
		Assert.notNull(educationRecord);
		Assert.isTrue(educationRecord.getId() != 0);

		HandyWorker handyWorker;
		Curriculum curriculum;

		handyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();
		curriculum = handyWorker.getCurriculum();
		final Collection<EducationRecord> curriculums = new HashSet<>(curriculum.getEducationRecords());

		curriculums.remove(educationRecord);
		curriculum.setEducationRecords(curriculums);

		this.educationRecordRepository.delete(educationRecord);
	}

}
