/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CustomerRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountService;
import domain.Application;
import domain.Category;
import domain.Customer;
import domain.FixUpTask;
import domain.HandyWorker;
import domain.Warranty;

@Service
@Transactional
public class CustomerService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private CustomerRepository		customerRepository;
	@Autowired
	private FixUpTaskService		fixUpTaskService;
	@Autowired
	private ComplaintService		complaintService;
	@Autowired
	private ApplicationService		applicationService;
	@Autowired
	private ActorService			actorService;
	@Autowired
	private EndorserService			endorserService;
	@Autowired
	private UserAccountService		userAccountService;
	@Autowired
	private ConfigurationService	configurationService;


	// Constructors -----------------------------------------------------------

	public CustomerService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Customer create() {
		Customer result;

		result = new Customer();
		//meterle el authority
		final UserAccount userAccount = new UserAccount();
		final Authority authotity = new Authority();
		authotity.setAuthority(Authority.CUSTOMER);
		final Collection<Authority> authorities = new ArrayList<>();
		authorities.add(authotity);
		userAccount.setAuthorities(authorities);
		result.setUserAccount(userAccount);

		return result;
	}
	public Collection<Customer> findAll() {
		Collection<Customer> result;

		result = this.customerRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Customer findOne(final int customerId) {
		Customer result;

		result = this.customerRepository.findOne(customerId);
		Assert.notNull(result);

		return result;
	}

	public Customer save(final Customer customer) {
		Assert.notNull(customer);

		final Customer result;

		if (customer.getId() != 0) {

			//comprobar si es el
			final UserAccount userAccount;
			userAccount = LoginService.getPrincipal();
			Assert.isTrue(customer.getUserAccount().equals(userAccount));
		}

		this.actorService.save(customer);
		this.userAccountService.save(customer.getUserAccount());
		this.endorserService.save(customer);
		result = this.customerRepository.save(customer);

		return result;
	}

	//	public void delete(final Customer customer) {
	//		Assert.notNull(customer);
	//		Assert.isTrue(customer.getId() != 0);
	//
	//		//comprueba si es el
	//		final UserAccount userAccount;
	//		userAccount = LoginService.getPrincipal();
	//		Assert.isTrue(customer.getUserAccount().equals(userAccount));
	//		//no puede tener fixUpTask 
	//		Assert.isTrue(this.fixUpTaskService.numFixUpTaskByCustomer(customer).equals(0));
	//		//no puede tener complaint
	//		Assert.isTrue(this.complaintService.numComplaintByCustomer(customer).equals(0));
	//
	//		this.customerRepository.delete(customer);
	//	}

	// Other business methods -------------------------------------------------

	public Customer findByPrincipal() {
		Customer result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.findByUserAccount(userAccount);
		Assert.notNull(result);

		return result;
	}

	public Customer findByUserAccount(final UserAccount userAccount) {
		Assert.notNull(userAccount);

		Customer result;

		result = this.customerRepository.findByUserAccountId(userAccount.getId());

		return result;
	}

	//R10

	public Collection<FixUpTask> listingFixUpTasksCreatedByCustomer(final int customerId) {
		return this.customerRepository.findByCustomerId(customerId);
	}

	public FixUpTask showFixUpTask(final int fixUpTaskId, final Customer customer) {
		final int userAccountId = LoginService.getPrincipal().getId();
		Assert.isTrue(userAccountId == customer.getUserAccount().getId());

		final FixUpTask res = this.fixUpTaskService.findOne(fixUpTaskId);
		return res;
	}

	public FixUpTask saveFixUpTaskCustomer(final Customer customer, final FixUpTask fixUpTask, final Category category, final Warranty warranty) {
		final int userAccountId = LoginService.getPrincipal().getId();
		Assert.isTrue(userAccountId == customer.getUserAccount().getId());
		//comprobamos valided de fechas
		Assert.isTrue(fixUpTask.getStartTime().before(fixUpTask.getEndTime()));
		//solo se pueden asociar fixUpTask finales
		Assert.isTrue(fixUpTask.getWarranty().getIsFinal());

		final FixUpTask res;

		if (fixUpTask.getId() != 0) {
			Assert.isTrue(fixUpTask.getCustomer().getId() == customer.getId());
		} else {

			//ponemos el customer que la crea
			fixUpTask.setCustomer(customer);
			//ponemos el momento de creacion
			fixUpTask.setMoment(new Date());
			//ponemos su ticker
			fixUpTask.setTicker(this.configurationService.getValidTicker());
		}

		//su categoty
		fixUpTask.setCategory(category);
		//su warranty
		fixUpTask.setWarranty(warranty);

		res = this.fixUpTaskService.save(fixUpTask);

		return res;

	}

	public void deleteFixUpTaskCustomer(final Customer customer, final FixUpTask f) {

		final UserAccount userAccount = LoginService.getPrincipal();
		Assert.isTrue(userAccount.getAuthorities().contains("CUSTOMER"));

		final int customerId = LoginService.getPrincipal().getId();
		Assert.isTrue(customerId == customer.getId());
		Assert.isTrue(f.getCustomer().getUserAccount().getId() == customerId);

		//una fixUpTask no puede tener complaint 
		Assert.isTrue(this.customerRepository.findComplaintByFixUpTaskId(f.getId()).size() == 0);
		//una fixUpTask no puede tener application
		Assert.isTrue(this.customerRepository.findApplicationsByFixUpTaskId(f.getId()).size() == 0);
		//una fixUpTask no puede tener phase
		Assert.isTrue(this.customerRepository.findPhaseByFixUpTaskId(f.getId()).size() == 0);

		this.fixUpTaskService.delete(f);
	}

	public Collection<Application> findApplicationsByCustomerId(final Customer customer) {
		Assert.notNull(customer);
		//si el que borra su cuenta era el de la cuenta
		final UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.isTrue(customer.getUserAccount().equals(userAccount));

		final Collection<Application> res = this.customerRepository.findApplicationsByCustomerId(customer.getId());
		return res;
	}

	//TODO revisar
	public Application updateCustomerApplication(final Customer customer, final Application application) {

		Assert.notNull(customer);
		Assert.notNull(application);
		//si el que borra su cuenta era el de la cuenta
		final UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.isTrue(customer.getUserAccount().equals(userAccount));

		//TODO coger la anterior con un select y ver que el estdo es pendig
		//hago un set de la aplicain y le meto el nuevo estado
		//le meto la crecdit card
		final Application res = this.applicationService.save(application);

		return res;
	}

	public Collection<HandyWorker> getRelatedHandyWorkers(final int customerId) {

		return this.customerRepository.findRelatedHandyWorkersByCustomerId(customerId);
	}

}
