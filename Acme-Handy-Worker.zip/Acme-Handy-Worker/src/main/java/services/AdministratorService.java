/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.AdministratorRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountService;
import domain.Actor;
import domain.Administrator;
import domain.Category;
import domain.Customer;
import domain.HandyWorker;
import domain.Message;
import domain.Referee;
import domain.Warranty;

@Service
@Transactional
public class AdministratorService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private AdministratorRepository	administratorRepository;

	// Business repository -----------------------------------------------------

	@Autowired
	private MessageService			messageService;
	@Autowired
	private ActorService			actorService;
	@Autowired
	private WarrantyService			warrantyService;
	@Autowired
	private CategoryService			categoryService;
	@Autowired
	private RefereeService			refereeService;
	@Autowired
	private UserAccountService		userAccountService;


	// Constructors -----------------------------------------------------------

	public AdministratorService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Administrator create() {

		Administrator result;
		result = new Administrator();

		final UserAccount userAccount = new UserAccount();
		final Authority authotity = new Authority();
		authotity.setAuthority(Authority.ADMIN);
		final Collection<Authority> authorities = new ArrayList<>();
		authorities.add(authotity);
		userAccount.setAuthorities(authorities);
		result.setUserAccount(userAccount);
		return result;
	}

	public Collection<Administrator> findAll() {
		Collection<Administrator> result;

		result = this.administratorRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Administrator findOne(final int administratorId) {
		Administrator result;

		result = this.administratorRepository.findOne(administratorId);
		Assert.notNull(result);

		return result;
	}

	public Administrator save(final Administrator administrator) {
		Assert.notNull(administrator);

		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Administrator result;

		if (!(administrator.getId() == 0)) {
			// comprobamos que el que la crear es un admin
			Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));
		} else {
			//comprobamos que es su cuenta
			Assert.isTrue(administrator.getUserAccount().equals(userAcount));
		}

		this.actorService.save(administrator);
		this.userAccountService.save(administrator.getUserAccount());

		result = this.administratorRepository.save(administrator);

		return result;
	}

	public void delete(final Administrator administrator) {
		Assert.notNull(administrator);
		Assert.isTrue(administrator.getId() != 0);

		//si el que borra su cuenta era el de la cuenta
		final UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.isTrue(administrator.getUserAccount().equals(userAccount));

		this.administratorRepository.delete(administrator);
	}

	// Other business methods -------------------------------------------------

	//R12.2

	public Collection<Warranty> listingAllWarrantiesByAdmin() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		return this.warrantyService.findAll();
	}

	public Warranty showWarrantyByAdminforId(final int warrantyId) {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		return this.warrantyService.findOne(warrantyId);
	}

	//R12.3

	public Collection<Category> listAllCategoriesByAdmin() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		return this.categoryService.findAll();
	}

	public Category showCategoryByAdminforId(final int CategoryId) {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		return this.categoryService.findOne(CategoryId);
	}

	//R 12.4

	public void messageToAll(final Message message) {
		Assert.notNull(message);

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//metemos en el sender el admin
		final Actor adminCreator = this.actorService.actorByUserAccount(userAcount);
		message.setSender(adminCreator);

		final Collection<Actor> allActors = this.actorService.findAll();
		//borramos a el mismo
		allActors.remove(adminCreator);
		message.setRecipients(allActors);

		this.messageService.save(message);
	}
	public Referee createNewReferee() {
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Referee res;
		res = this.refereeService.create();

		return res;

	}

	public Collection<Actor> listSuspiciousActor() {

		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Actor> suspiciousActors = this.administratorRepository.suspiciousActors();

		return suspiciousActors;

	}

	public void banActor(final Actor actor) {
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		if (actor.getIsSuspicious() == true) {
			actor.setIsBanned(true);
		}

		this.actorService.save(actor);
	}

	public void unbanActor(final Actor actor) {
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));
		if (actor.getIsBanned() == true) {
			actor.setIsBanned(false);
		}
		actor.setIsSuspicious(false);
		this.actorService.save(actor);
	}

	//R12.5

	public Collection<Double> ammsNumberFixUpTasksUser() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsNumberFixUpTasksUser();

		return result;
	}

	public Collection<Double> ammsNumberApplicationsFixUpTask() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsNumberApplicationsFixUpTask();

		return result;
	}

	public Collection<Double> ammsMaximumPriceFixUpTasks() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsMaximumPriceFixUpTasks();

		return result;
	}

	public Collection<Double> ammsPriceOfferedApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsPriceOfferedApplications();

		return result;
	}

	public Double RatioPendingApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		Double result;

		result = this.administratorRepository.RatioPendingApplications();

		return result;
	}

	public Double RatioAcceptedApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		Double result;

		result = this.administratorRepository.RatioAcceptedApplications();

		return result;
	}

	public Double RatioRejectedApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		Double result;

		result = this.administratorRepository.RatioRejectedApplications();

		return result;
	}

	public Double RatioPendingCannotChangesStatus() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		Double result;

		result = this.administratorRepository.RatioPendingApplications();

		return result;
	}

	public Collection<Customer> CustomerPublished10MoreFixUpTasks() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Customer> result = this.administratorRepository.CustomerPublished10MoreFixUpTasks();

		return result;
	}
	public Collection<HandyWorker> handyPublished10MoreApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<HandyWorker> result = this.administratorRepository.handyPublished10MoreApplications();

		return result;
	}

	public Collection<Double> ammsNumberComplaintsFixUpTasks() {

		final Collection<Double> result = this.administratorRepository.ammsNumberComplaintsFixUpTasks();

		return result;
	}
	public Collection<Double> ammsNumberNotesRefereeReport() {

		final Collection<Double> result = this.administratorRepository.ammsNumberNotesRefereeReport();

		return result;
	}

	public Double RatioFixUpTasksComplaint() {

		Double result;

		result = this.administratorRepository.RatioFixUpTasksComplaint();

		return result;
	}

	public Collection<Customer> TopThreeCustomersComplaints() {
		final Collection<Customer> result = this.administratorRepository.topThreeCustomersComplaints();

		return result;
	}
	public Collection<HandyWorker> TopThreeHandyWorkersComplaints() {
		final Collection<HandyWorker> result = this.administratorRepository.topThreeHandyWorkersComplaints();

		return result;
	}

}
