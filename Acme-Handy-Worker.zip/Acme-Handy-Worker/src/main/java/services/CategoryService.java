/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CategoryRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import domain.Category;
import domain.FixUpTask;

@Service
@Transactional
public class CategoryService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private CategoryRepository	categoryRepository;
	@Autowired
	private FixUpTaskService	fixUpTaskService;


	// Constructors -----------------------------------------------------------

	public CategoryService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Category create() {
		Category result;

		result = new Category();

		return result;
	}

	public Collection<Category> findAll() {
		List<Category> allCategories;
		final List<Category> categoriesToReturn = new ArrayList<>();
		final Collection<Category> result = new ArrayList<>();

		allCategories = this.categoryRepository.findAll();
		Assert.notNull(allCategories);

		for (final Category category : allCategories)
			if (!category.getName().equals("CATEGORY"))
				categoriesToReturn.add(category);

		result.addAll(categoriesToReturn);

		return result;
	}
	public Category findOne(final int categoryId) {
		Category result;

		result = this.categoryRepository.findOne(categoryId);
		Assert.notNull(result);

		return result;
	}

	public Category save(final Category category) {
		//solo lo usan admin
		this.checkPrincipalIsAdmin();

		Assert.notNull(category);

		Category result;
		result = this.categoryRepository.save(category);

		return result;
	}

	public void delete(final Category category) {
		//solo lo usan admin
		this.checkPrincipalIsAdmin();

		Assert.notNull(category);
		Assert.isTrue(category.getId() != 0);

		//una category solo puede ser borrada si no tiene hijas
		Assert.isTrue(this.categoryRepository.getChildren(category.getId()).size() == 0);

		//solo lo usan admin
		this.checkPrincipalIsAdmin();

		Assert.notNull(category);
		Assert.isTrue(category.getId() != 0);

		//una category solo puede ser borrada si no tiene hijas
		Assert.isTrue(this.categoryRepository.getChildren(category.getId()).size() == 0);

		//Borrar category hija del padre, si lo tiene
		final Collection<Category> categories = this.categoryRepository.findAll();
		final Category parentCategory = this.findOne(18751);

		for (final Category c : categories)
			if (c.getCategories().contains(category)) {
				c.getCategories().remove(category);
				this.categoryRepository.save(c);
			}

		//Borrar category del fix-up task, si este la tiene

		final Collection<FixUpTask> fixUpTasks = this.fixUpTaskService.findAll();

		for (final FixUpTask f : fixUpTasks)
			if (f.getCategory().equals(category)) {
				f.setCategory(parentCategory);
				this.fixUpTaskService.save(f);
			}

		this.categoryRepository.delete(category);
	}

	// Other business methods -------------------------------------------------

	protected void checkPrincipalIsAdmin() {
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		final Authority adminAuthority = new Authority();
		adminAuthority.setAuthority("ADMIN");

		Assert.isTrue(userAccount.getAuthorities().contains(adminAuthority));
	}
}
