
package services;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.EndorserRecordRepository;
import domain.Curriculum;
import domain.EndorserRecord;
import domain.HandyWorker;

@Service
@Transactional
public class EndorserRecordService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private EndorserRecordRepository	endorserRecordRepository;
	@Autowired
	private HandyWorkerService			handyWorkerService;
	@Autowired
	private CurriculumService			curriculumService;


	// Constructors -----------------------------------------------------------

	public EndorserRecordService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public EndorserRecord create() {
		EndorserRecord result;

		result = new EndorserRecord();

		return result;
	}

	public Collection<EndorserRecord> findAll() {
		Collection<EndorserRecord> result;

		result = this.endorserRecordRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public EndorserRecord findOne(final int endorserRecordId) {
		EndorserRecord result;

		result = this.endorserRecordRepository.findOne(endorserRecordId);
		Assert.notNull(result);

		return result;
	}

	public EndorserRecord save(final EndorserRecord endorserRecord) {
		Assert.notNull(endorserRecord);

		EndorserRecord result;
		HandyWorker handyWorker;
		Curriculum curriculum;

		handyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();
		curriculum = handyWorker.getCurriculum();
		final Collection<EndorserRecord> curriculums = new HashSet<>(curriculum.getEndorserRecords());
		System.out.println(curriculums + " ver curriculums que tenia");

		System.out.println(endorserRecord + "endorser que he metido");
		curriculums.add(endorserRecord);
		curriculum.setEndorserRecords(curriculums);
		result = this.endorserRecordRepository.save(endorserRecord);

		this.curriculumService.save(curriculum);
		return result;
	}

	public void delete(final EndorserRecord endorserRecord) {
		Assert.notNull(endorserRecord);
		Assert.isTrue(endorserRecord.getId() != 0);

		HandyWorker handyWorker;
		Curriculum curriculum;

		handyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();
		curriculum = handyWorker.getCurriculum();
		final Collection<EndorserRecord> curriculums = new HashSet<>(curriculum.getEndorserRecords());

		curriculums.remove(endorserRecord);
		curriculum.setEndorserRecords(curriculums);

		this.endorserRecordRepository.delete(endorserRecord);
	}

}
