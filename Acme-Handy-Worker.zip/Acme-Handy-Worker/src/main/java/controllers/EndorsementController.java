/*
 * BoxController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.CustomerService;
import services.EndorsementService;
import services.EndorserService;
import services.HandyWorkerService;
import domain.Customer;
import domain.Endorsement;
import domain.Endorser;
import domain.HandyWorker;

@Controller
@RequestMapping("/endorsement")
public class EndorsementController extends AbstractController {

	//Managed services
	@Autowired
	private EndorsementService	endorsementService;

	@Autowired
	private EndorserService		endorserService;

	@Autowired
	private HandyWorkerService	handyWorkerService;

	@Autowired
	private CustomerService		customerService;


	// Constructors -----------------------------------------------------------

	public EndorsementController() {
		super();
	}

	// List ---------------------------------------------------------------		

	@RequestMapping(value = "customer/list-sent", method = RequestMethod.GET)
	public ModelAndView listSentByCustomer() {
		ModelAndView result;
		Collection<Endorsement> endorsements = null;

		endorsements = this.endorserService.principalEndorsementsSent();

		result = new ModelAndView("endorsement/endorsementList");

		result.addObject("endorsements", endorsements);
		result.addObject("forMe", false);
		result.addObject("rol", "customer");
		result.addObject("requestURI", "endorsement/customer/list-sent.do");

		return result;
	}

	@RequestMapping(value = "handy-worker/list-sent", method = RequestMethod.GET)
	public ModelAndView listSentByHandyWorker() {
		ModelAndView result;
		Collection<Endorsement> endorsements = null;

		endorsements = this.endorserService.principalEndorsementsSent();

		result = new ModelAndView("endorsement/endorsementList");

		result.addObject("endorsements", endorsements);
		result.addObject("forMe", false);
		result.addObject("rol", "handy-worker");
		result.addObject("requestURI", "endorsement/handy-worker/list-sent.do");

		return result;
	}
	@RequestMapping(value = "customer/list-received", method = RequestMethod.GET)
	public ModelAndView listReceivedByCustomer() {
		ModelAndView result;
		Collection<Endorsement> endorsements = null;

		endorsements = this.endorserService.principalEndorsementsReceived();

		result = new ModelAndView("endorsement/endorsementList");

		result.addObject("forMe", true);
		result.addObject("endorsements", endorsements);
		result.addObject("rol", "customer");
		result.addObject("requestURI", "endorsement/customer/list-received.do");

		return result;
	}

	@RequestMapping(value = "handy-worker/list-received", method = RequestMethod.GET)
	public ModelAndView listReceivedByHandyWorker() {
		ModelAndView result;
		Collection<Endorsement> endorsements = null;

		endorsements = this.endorserService.principalEndorsementsReceived();

		result = new ModelAndView("endorsement/endorsementList");

		result.addObject("forMe", true);
		result.addObject("endorsements", endorsements);
		result.addObject("rol", "handy-worker");
		result.addObject("requestURI", "endorsement/handy-worker/list-received.do");

		return result;
	}
	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/customer/create", method = RequestMethod.GET)
	public ModelAndView createByCustomer() {
		final ModelAndView result;
		Endorsement endorsement;

		endorsement = this.endorsementService.create();
		result = this.createEditModelAndView(endorsement);

		final Collection<Endorser> possibleEndorsers = new ArrayList<>();

		for (final HandyWorker handyWorker : this.endorserService.findRelatedHandyWorkers(this.customerService.findCustomerByPrincipal()))
			possibleEndorsers.add(handyWorker);

		result.addObject("rol", "customer");
		result.addObject("possibleEndorsers", possibleEndorsers);
		result.addObject("toShow", false);

		return result;
	}
	@RequestMapping(value = "/handy-worker/create", method = RequestMethod.GET)
	public ModelAndView createByHandyWorker() {
		final ModelAndView result;
		Endorsement endorsement;

		endorsement = this.endorsementService.create();
		result = this.createEditModelAndView(endorsement);

		final Collection<Endorser> possibleEndorsers = new ArrayList<>();

		for (final Customer customer : this.endorserService.findRelatedCustomers(this.handyWorkerService.findHandyWorkerByPrincipal()))
			possibleEndorsers.add(customer);

		result.addObject("rol", "handy-worker");
		result.addObject("possibleEndorsers", possibleEndorsers);
		result.addObject("toShow", false);
		return result;
	}
	// Edit ---------------------------------------------------------------		

	@RequestMapping(value = "customer/edit", method = RequestMethod.GET)
	public ModelAndView editByCustomer(@RequestParam final int endorsementId, @RequestParam final int toShow) {
		final ModelAndView result;
		Endorsement endorsement;

		endorsement = this.endorsementService.findOne(endorsementId);
		Assert.notNull(endorsement);

		result = this.createEditModelAndView(endorsement);

		final Collection<Endorser> possibleEndorsers = new ArrayList<>();
		possibleEndorsers.add(endorsement.getRecipient());

		result.addObject("possibleEndorsers", possibleEndorsers);

		if (toShow == 0) {
			//Assert para comprobar que un endorser no edita endorsements que no son suyos
			Assert.isTrue((this.endorserService.findEndorserByPrincipal().getId() == endorsement.getSender().getId()));
			result.addObject("toShow", false);
		} else
			result.addObject("toShow", true);

		result.addObject("rol", "customer");

		//Comprobamos de que vista accede al show o edit para ver a que listado habra que llevarle si pulsa cancel
		//Si es sender, procedera del listado de endorsements enviados, y si no, del otro
		final String urlcancelButtonUrl;
		if (this.endorserService.findEndorserByPrincipal().getId() == endorsement.getSender().getId())
			urlcancelButtonUrl = "list-sent";
		else
			urlcancelButtonUrl = "list-received";

		result.addObject("urlcancelButtonUrl", urlcancelButtonUrl);

		return result;
	}
	@RequestMapping(value = "handy-worker/edit", method = RequestMethod.GET)
	public ModelAndView editByHandyWorker(@RequestParam final int endorsementId, @RequestParam final int toShow) {
		final ModelAndView result;
		Endorsement endorsement;

		endorsement = this.endorsementService.findOne(endorsementId);
		Assert.notNull(endorsement);

		result = this.createEditModelAndView(endorsement);

		final Collection<Endorser> possibleEndorsers = new ArrayList<>();
		possibleEndorsers.add(endorsement.getRecipient());

		result.addObject("possibleEndorsers", possibleEndorsers);

		if (toShow == 0) {
			//Assert para comprobar que un endorser no edita endorsements que no son suyos
			Assert.isTrue((this.endorserService.findEndorserByPrincipal().getId() == endorsement.getSender().getId()));
			result.addObject("toShow", false);
		} else
			result.addObject("toShow", true);

		//Comprobamos de que vista accede al show o edit para ver a que listado habra que llevarle si pulsa cancel
		//Si es sender, procedera del listado de endorsements enviados, y si no, del otro
		final String urlcancelButtonUrl;
		if (this.endorserService.findEndorserByPrincipal().getId() == endorsement.getSender().getId())
			urlcancelButtonUrl = "list-sent";
		else
			urlcancelButtonUrl = "list-received";

		result.addObject("urlcancelButtonUrl", urlcancelButtonUrl);

		result.addObject("rol", "handy-worker");
		return result;
	}

	// Save ---------------------------------------------------------------		
	@RequestMapping(value = "customer/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView customerSave(@Valid final Endorsement endorsement, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = this.createEditModelAndView(endorsement);

			final Collection<Endorser> possibleEndorsers = new ArrayList<>();

			for (final HandyWorker handyWorker : this.endorserService.findRelatedHandyWorkers(this.customerService.findCustomerByPrincipal()))
				possibleEndorsers.add(handyWorker);

			result.addObject("rol", "customer");
			result.addObject("possibleEndorsers", possibleEndorsers);
			result.addObject("toShow", false);
		} else
			try {
				this.endorserService.createAndUpdateEndorsemet(endorsement);
				result = new ModelAndView("redirect:list-sent.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(endorsement, "endorsement.commit.error");

				final Collection<Endorser> possibleEndorsers = new ArrayList<>();

				for (final HandyWorker handyWorker : this.endorserService.findRelatedHandyWorkers(this.customerService.findCustomerByPrincipal()))
					possibleEndorsers.add(handyWorker);

				result.addObject("rol", "customer");
				result.addObject("possibleEndorsers", possibleEndorsers);
				result.addObject("toShow", false);
			}

		return result;
	}

	@RequestMapping(value = "handy-worker/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView handyWorkerSave(@Valid final Endorsement endorsement, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = this.createEditModelAndView(endorsement);
			final Collection<Endorser> possibleEndorsers = new ArrayList<>();

			for (final Customer customer : this.endorserService.findRelatedCustomers(this.handyWorkerService.findHandyWorkerByPrincipal()))
				possibleEndorsers.add(customer);

			result.addObject("rol", "handy-worker");
			result.addObject("possibleEndorsers", possibleEndorsers);
			result.addObject("toShow", false);
		} else
			try {
				this.endorserService.createAndUpdateEndorsemet(endorsement);
				result = new ModelAndView("redirect:list-sent.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(endorsement, "endorsement.commit.error");

				final Collection<Endorser> possibleEndorsers = new ArrayList<>();

				for (final Customer customer : this.endorserService.findRelatedCustomers(this.handyWorkerService.findHandyWorkerByPrincipal()))
					possibleEndorsers.add(customer);

				result.addObject("rol", "handy-worker");
				result.addObject("possibleEndorsers", possibleEndorsers);
				result.addObject("toShow", false);
			}

		return result;
	}

	// Delete ---------------------------------------------------------------		
	@RequestMapping(value = "customer/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView customerDelete(final Endorsement endorsement, final BindingResult binding) {
		ModelAndView result;

		try {
			this.endorserService.deleteEndorsement(endorsement);
			result = new ModelAndView("redirect:list-sent.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(endorsement, "endorsement.delete.error");

			final Collection<Endorser> possibleEndorsers = new ArrayList<>();

			for (final HandyWorker handyWorker : this.endorserService.findRelatedHandyWorkers(this.customerService.findCustomerByPrincipal()))
				possibleEndorsers.add(handyWorker);

			result.addObject("rol", "customer");
			result.addObject("possibleEndorsers", possibleEndorsers);
			result.addObject("toShow", false);
		}

		return result;
	}

	@RequestMapping(value = "handy-worker/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView handyWorkerDelete(final Endorsement endorsement, final BindingResult binding) {
		ModelAndView result;

		try {
			this.endorserService.deleteEndorsement(endorsement);
			result = new ModelAndView("redirect:list-sent.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(endorsement, "endorsement.delete.error");

			final Collection<Endorser> possibleEndorsers = new ArrayList<>();

			for (final Customer customer : this.endorserService.findRelatedCustomers(this.handyWorkerService.findHandyWorkerByPrincipal()))
				possibleEndorsers.add(customer);

			result.addObject("rol", "handy-worker");
			result.addObject("possibleEndorsers", possibleEndorsers);
			result.addObject("toShow", false);
		}

		return result;
	}

	// Ancillary Methods -----------------------------------------------------
	protected ModelAndView createEditModelAndView(final Endorsement endorsement) {
		ModelAndView result;

		result = this.createEditModelAndView(endorsement, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Endorsement endorsement, final String messageCode) {
		ModelAndView result;
		result = new ModelAndView("endorsement/endorsementEdit");

		result.addObject("endorsement", endorsement);
		result.addObject("message", messageCode);

		return result;
	}
}
