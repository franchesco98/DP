
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.CategoryService;
import domain.Category;

@Controller
@RequestMapping("/categories")
public class CategoryController {

	// Services ---------------------------------------------------------------

	@Autowired
	private CategoryService	categoryService;


	// Constructors -----------------------------------------------------------

	public CategoryController() {
		super();
	}

	// List categories --------------------------------------------------------

	@RequestMapping("/administrator/list")
	public ModelAndView showCategories() {
		ModelAndView result;
		final Collection<Category> categories = this.categoryService.findAll();

		result = new ModelAndView("categories/administrator/list");

		result.addObject("categories", categories);

		return result;
	}

	// Create category --------------------------------------------------------

	@RequestMapping("/administrator/create")
	public ModelAndView create() {
		ModelAndView result;
		final Category category = this.categoryService.create();
		final Collection<Category> allCategories = this.categoryService.findAll();

		result = new ModelAndView("categories/administrator/create");
		result.addObject("category", category);
		result.addObject("allCategories", allCategories);

		result.addObject("toShow", false);
		result.addObject("create", true);

		return result;
	}

	// Show category ----------------------------------------------------------

	@RequestMapping("/administrator/show")
	public ModelAndView showCategory(@RequestParam final int categoryId) {
		ModelAndView result;
		Category category;

		category = this.categoryService.findOne(categoryId);
		Assert.notNull(category);

		result = new ModelAndView("categories/administrator/show");

		result.addObject("category", category);
		result.addObject("toShow", true);

		return result;
	}

	// Edit category ----------------------------------------------------------

	@RequestMapping("/administrator/edit")
	public ModelAndView edit(@RequestParam final int categoryId) {
		ModelAndView result;
		final Category category = this.categoryService.findOne(categoryId);
		Assert.notNull(category);

		result = this.createEditModelAndView(category);

		return result;
	}

	// Save category ----------------------------------------------------------

	@RequestMapping(value = "/administrator/save", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Category category, final BindingResult binding, @RequestParam(defaultValue = "") final String categories) {
		ModelAndView result;
		Category savedCategory = null;
		String parentCategoryId = categories;

		if (parentCategoryId.equals(""))
			parentCategoryId = "18751";
		else if (categories.charAt(0) == ',')
			parentCategoryId = categories.split(",")[1];

		final Category parentCategory = this.categoryService.findOne(new Integer(parentCategoryId));

		if (binding.hasErrors())
			result = this.createEditModelAndView(category);
		else
			try {

				savedCategory = this.categoryService.save(category);
				parentCategory.getCategories().add(savedCategory);
				this.categoryService.save(parentCategory);

				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {

				result = this.createEditModelAndView(category, "category.commit.error");
			}

		return result;
	}

	// Delete category --------------------------------------------------------

	@RequestMapping(value = "/administrator/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int categoryId) {
		ModelAndView result;
		final Category category = this.categoryService.findOne(categoryId);

		this.categoryService.delete(category);

		result = this.showCategories();

		return result;

	}

	protected ModelAndView createEditModelAndView(final Category category) {
		ModelAndView result;

		result = this.createEditModelAndView(category, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Category category, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("categories/administrator/edit");
		result.addObject("category", category);

		result.addObject("toShow", false);
		result.addObject("create", false);
		result.addObject("message", messageCode);

		return result;
	}

}
