/*
 * AdministratorController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.AdministratorService;
import services.EndorserService;
import services.WarrantyService;
import domain.Actor;
import domain.Administrator;
import domain.Customer;
import domain.HandyWorker;
import domain.Warranty;

@Controller
@RequestMapping("/admin")
public class AdministratorController extends AbstractController {

	// Services ---------------------------------------------------------------

	@Autowired
	private AdministratorService	administratorService;
	@Autowired
	private WarrantyService			warrantyService;
	@Autowired
	private ActorService			actorService;
	@Autowired
	private EndorserService			endorserService;


	// Constructors -----------------------------------------------------------

	public AdministratorController() {
		super();
	}

	// Calculate-score -----------------------------------------------------------
	@RequestMapping("/calculate-score")
	public ModelAndView calculateScore() {
		ModelAndView result;

		try {
			this.endorserService.computedScore();
			result = new ModelAndView("welcome/index");
			result.addObject("success", true);
		} catch (final Exception oops) {
			result = new ModelAndView("welcome/index");
			result.addObject("fail", true);
		}

		return result;
	}

	// Dashboard --------------------------------------------------------------

	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public ModelAndView dashboard() {
		final ModelAndView result;
		final List<Double> fixUpTasksPerUser = this.administratorService.ammsNumberFixUpTasksUser();
		final List<Double> applicationsPerFixUpTask = this.administratorService.ammsNumberApplicationsFixUpTask();
		final List<Double> maximumPricePerFixUpTasks = this.administratorService.ammsMaximumPriceFixUpTasks();
		final List<Double> priceOfferedPerApplications = this.administratorService.ammsPriceOfferedApplications();
		final Double ratioPendingApplications = this.administratorService.RatioPendingApplications();
		final Double ratioAcceptedApplications = this.administratorService.RatioAcceptedApplications();
		final Double ratioRejectedApplications = this.administratorService.RatioRejectedApplications();
		final Double ratioApplicationsCannotChangeStatus = this.administratorService.RatioPendingCannotChangesStatus();
		final Collection<Customer> customerPublished10MoreAvg = this.administratorService.CustomerPublished10MoreFixUpTasks();
		final Collection<HandyWorker> handyWorkerPublished10MoreAvg = this.administratorService.handyPublished10MoreApplications();
		final List<Double> numberComplaintsFixUpTasks = this.administratorService.ammsNumberComplaintsFixUpTasks();
		final List<Double> numberNotesRefereeReport = this.administratorService.ammsNumberNotesRefereeReport();

		result = new ModelAndView("admin/dashboard");

		result.addObject("fixUpTasksPerUserAvg", fixUpTasksPerUser.get(0));
		result.addObject("fixUpTasksPerUserMin", fixUpTasksPerUser.get(1));
		result.addObject("fixUpTasksPerUserMax", fixUpTasksPerUser.get(2));
		result.addObject("fixUpTasksPerUserDesv", fixUpTasksPerUser.get(3));

		result.addObject("applicationsPerFixUpTaskAvg", applicationsPerFixUpTask.get(0));
		result.addObject("applicationsPerFixUpTaskMin", applicationsPerFixUpTask.get(1));
		result.addObject("applicationsPerFixUpTaskMax", applicationsPerFixUpTask.get(2));
		result.addObject("applicationsPerFixUpTaskDesv", applicationsPerFixUpTask.get(3));

		result.addObject("maximumPricePerFixUpTasksAvg", maximumPricePerFixUpTasks.get(0));
		result.addObject("maximumPricePerFixUpTasksMin", maximumPricePerFixUpTasks.get(1));
		result.addObject("maximumPricePerFixUpTasksMax", maximumPricePerFixUpTasks.get(2));
		result.addObject("maximumPricePerFixUpTasksDesv", maximumPricePerFixUpTasks.get(3));

		result.addObject("priceOfferedPerApplicationsAvg", priceOfferedPerApplications.get(0));
		result.addObject("priceOfferedPerApplicationsMin", priceOfferedPerApplications.get(1));
		result.addObject("priceOfferedPerApplicationsMax", priceOfferedPerApplications.get(2));
		result.addObject("priceOfferedPerApplicationsDesv", priceOfferedPerApplications.get(3));

		result.addObject("ratioPendingApplications", ratioPendingApplications);
		result.addObject("ratioAcceptedApplications", ratioAcceptedApplications);
		result.addObject("ratioRejectedApplications", ratioRejectedApplications);
		result.addObject("ratioApplicationsCannotChangeStatus", ratioApplicationsCannotChangeStatus);

		result.addObject("customerPublished10MoreAvg", customerPublished10MoreAvg);
		result.addObject("handyWorkerPublished10MoreAvg", handyWorkerPublished10MoreAvg);

		result.addObject("numberComplaintsFixUpTasksAvg", numberComplaintsFixUpTasks.get(0));
		result.addObject("numberComplaintsFixUpTasksMin", numberComplaintsFixUpTasks.get(1));
		result.addObject("numberComplaintsFixUpTasksMax", numberComplaintsFixUpTasks.get(2));
		result.addObject("numberComplaintsFixUpTasksDesv", numberComplaintsFixUpTasks.get(3));

		result.addObject("numberNotesRefereeReportAvg", numberNotesRefereeReport.get(0));
		result.addObject("numberNotesRefereeReportMin", numberNotesRefereeReport.get(1));
		result.addObject("numberNotesRefereeReportMax", numberNotesRefereeReport.get(2));
		result.addObject("numberNotesRefereeReportDesv", numberNotesRefereeReport.get(3));

		return result;
	}
	// Create new admin ---------------------------------------------------------------		

	@RequestMapping("/create")
	public ModelAndView create() {
		ModelAndView result;
		Administrator admin;
		admin = this.administratorService.create();

		result = this.createEditModelAndView(admin);

		return result;
	}

	// Save created admin -------------------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Administrator admin, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = this.createEditModelAndView(admin, null, 1);
			System.out.println(binding);
		} else
			try {

				this.administratorService.save(admin);

				result = new ModelAndView("redirect:index.do");
			} catch (final Throwable oops) {

				result = this.createEditModelAndView(admin, "admin.commit.error", 1);
			}

		return result;
	}

	// List suspicious actors ------------------------------------------------
	@RequestMapping("/suspiciousActors/list")
	public ModelAndView listActors() {
		final ModelAndView result;
		final Collection<Actor> actors = this.actorService.findAll();

		result = new ModelAndView("admin/actorsList");
		result.addObject("actors", actors);

		return result;
	}

	@RequestMapping(value = "/suspiciousActors/manageUserAccess", method = RequestMethod.GET)
	public ModelAndView manageUserAccess(@RequestParam final int actorId) {
		ModelAndView result;
		final Actor actor = this.actorService.findOne(actorId);

		this.actorService.changeAccountNonLocked(actor);

		result = this.listActors();

		return result;
	}

	// Action-2 ---------------------------------------------------------------
	@RequestMapping("/warranties/list")
	public ModelAndView showWarranties() {
		ModelAndView result;
		final Collection<Warranty> warranties = this.warrantyService.findAll();

		result = new ModelAndView("admin/warranties/list");

		result.addObject("warranties", warranties);

		return result;
	}

	@RequestMapping("/warranties/create")
	public ModelAndView createWarranty() {
		ModelAndView result;
		final Warranty warranty = this.warrantyService.create();

		result = new ModelAndView("admin/warranties/create");
		result.addObject("warranty", warranty);

		result.addObject("toShow", false);

		return result;
	}

	@RequestMapping("/warranties/show")
	public ModelAndView showWarranty(@RequestParam final int warrantyId) {
		ModelAndView result;
		final Warranty warranty = this.warrantyService.findOne(warrantyId);
		Assert.notNull(warranty);

		result = new ModelAndView("admin/warranties/show");
		result.addObject("warranty", warranty);
		result.addObject("toShow", true);

		return result;
	}

	@RequestMapping("/warranties/edit")
	public ModelAndView editWarranty(@RequestParam final int warrantyId) {
		ModelAndView result;
		final Warranty warranty = this.warrantyService.findOne(warrantyId);
		Assert.notNull(warranty);

		result = this.createEditModelAndView(warranty, null);

		return result;
	}

	@RequestMapping(value = "/warranties/save", method = RequestMethod.POST, params = "save")
	public ModelAndView saveWarranty(@Valid final Warranty warranty, final BindingResult binding, @RequestParam(defaultValue = "false") final String isFinal) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(warranty, null);
		else
			try {

				warranty.setIsFinal(new Boolean(isFinal));
				this.warrantyService.save(warranty);

				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {

				result = this.createEditModelAndView(warranty, "warranty.commit.error");
			}

		return result;
	}

	@RequestMapping(value = "/warranties/delete", method = RequestMethod.GET)
	public ModelAndView deleteWarranty(@RequestParam final int warrantyId) {
		ModelAndView result;
		final Warranty warranty = this.warrantyService.findOne(warrantyId);

		this.warrantyService.delete(warranty);

		result = this.showWarranties();

		return result;
	}

	protected ModelAndView createEditModelAndView(final Administrator admin) {
		ModelAndView result;
		final String rol = "admin";
		final Boolean toShow = false;
		result = new ModelAndView("actor/edit");
		result.addObject("admin", admin);
		result.addObject("rol", rol);
		result.addObject("toShow", toShow);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Administrator admin, final String messageCode, final int edit) {
		ModelAndView result;

		Boolean toShow = null;
		if (edit == 0)
			toShow = true;
		else
			toShow = false;

		result = new ModelAndView("actor/edit");
		result.addObject("admin", admin);

		result.addObject("toShow", toShow);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Warranty warranty, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("admin/warranties/edit");
		result.addObject("warranty", warranty);

		result.addObject("toShow", false);

		return result;
	}

}
