/*
 * handyWorkerController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.Authority;
import services.HandyWorkerService;
import domain.Box;
import domain.HandyWorker;

@Controller
@RequestMapping("/handyworker")
public class HandyWorkerController extends AbstractController {

	//Managed services
	@Autowired
	private HandyWorkerService	handyWorkerService;


	// Constructors -----------------------------------------------------------

	public HandyWorkerController() {
		super();
	}

	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		HandyWorker handyWorker;

		handyWorker = this.handyWorkerService.create();

		result = this.createEditModelAndView(handyWorker);

		return result;
	}

	// Save ---------------------------------------------------------------
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final HandyWorker handyWorker, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = this.createEditModelAndView(handyWorker);

			System.out.println("Address: " + handyWorker.getAddress());
			System.out.println("Email: " + handyWorker.getEmail());
			System.out.println("IsSuspicious: " + handyWorker.getIsSuspicious());
			System.out.println("Middle name: " + handyWorker.getMiddleName());
			System.out.println("Name: " + handyWorker.getName());
			System.out.println("Phone number: " + handyWorker.getPhoneNumber());
			System.out.println("Photo: " + handyWorker.getPhoto());
			System.out.println("Surname: " + handyWorker.getSurname());
			for (final Box b : handyWorker.getBoxes())
				System.out.println("\tBox: " + b.getName());
			System.out.println("Nick: " + handyWorker.getUserAccount().getUsername());
			System.out.println("Password: " + handyWorker.getUserAccount().getPassword());
			for (final Authority a : handyWorker.getUserAccount().getAuthorities())
				System.out.println("\tAuthority: " + a);
		} else
			try {

				this.handyWorkerService.save(handyWorker);

				result = new ModelAndView("redirect:/security/login.do");
			} catch (final Throwable oops) {

				result = this.createEditModelAndView(handyWorker, "handyworker.commit.error");
			}
		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int handyWorkerId) {
		ModelAndView result;
		HandyWorker handyWorker;

		handyWorker = this.handyWorkerService.findOne(handyWorkerId);
		Assert.notNull(handyWorker);

		result = this.createEditModelAndView(handyWorker);

		return result;
	}

	protected ModelAndView createEditModelAndView(final HandyWorker handyWorker) {
		ModelAndView result;

		result = this.createEditModelAndView(handyWorker, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final HandyWorker handyworker, final String messageCode) {
		ModelAndView result;
		final String rol = "handyworker";
		final Boolean toShow = false;
		result = new ModelAndView("actor/edit");
		result.addObject("handyworker", handyworker);
		result.addObject("rol", rol);
		result.addObject("toShow", toShow);

		return result;
	}
}
