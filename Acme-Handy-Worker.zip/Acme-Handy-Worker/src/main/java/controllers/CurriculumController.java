
package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.CurriculumService;
import services.HandyWorkerService;
import domain.Curriculum;
import domain.EducationRecord;
import domain.EndorserRecord;
import domain.MiscellaneousRecord;
import domain.PersonalRecord;
import domain.ProfessionalRecord;

@Controller
@RequestMapping("/curriculum/handyworker")
public class CurriculumController extends AbstractController {

	// Services --------------------------------------------------

	@Autowired
	private CurriculumService	curriculumService;

	@Autowired
	private HandyWorkerService	handyWorkerService;


	// Constructors ----------------------------------------------

	public CurriculumController() {
		super();
	}

	// Display ----------------------------------------------------

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display() {
		ModelAndView result;
		Curriculum curriculum;
		PersonalRecord personalRecord;
		Collection<ProfessionalRecord> professionalRecord;
		Collection<MiscellaneousRecord> miscellaneousRecord;
		Collection<EducationRecord> educationRecord;
		Collection<EndorserRecord> endorserRecord;

		curriculum = this.handyWorkerService.listingCurriculumCreatedByHandyWorkerPrincipal();
		Assert.notNull(curriculum);
		result = new ModelAndView("curriculum/display");
		personalRecord = curriculum.getPersonalRecord();
		professionalRecord = curriculum.getProfessionalRecords();
		miscellaneousRecord = curriculum.getMiscellaneousRecords();
		educationRecord = curriculum.getEducationRecords();
		endorserRecord = curriculum.getEndorserRecords();
		final Integer personalRecordId = personalRecord.getId();

		result.addObject("curriculum", curriculum);
		result.addObject("personalRecord", personalRecord);
		result.addObject("personalRecordId", personalRecordId);
		result.addObject("professionalRecords", professionalRecord);
		result.addObject("miscellaneousRecords", miscellaneousRecord);
		result.addObject("educationRecords", educationRecord);
		result.addObject("endorserRecords", endorserRecord);

		return result;
	}
}
