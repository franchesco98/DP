
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Category;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {

	//TODO tengo 	que sacar las categorias hijas dada una categoria,
	//esto seria ver que la id que me entra no este en la columna categories de la 
	//tabla categoryCategories
	@Query("select conunt(c.categories) from CategoryCategories c where c.categories = ?1 distint")
	Collection<Category> getChildren(int categoryId);

}
