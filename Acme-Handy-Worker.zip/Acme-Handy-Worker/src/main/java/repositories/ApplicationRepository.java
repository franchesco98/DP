
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Application;
import domain.Phase;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Integer> {

	@Query("select p from phase p where p.application.id = ?1")
	Collection<Phase> findAllPhasesByApplicationId(int applicationId);

}
