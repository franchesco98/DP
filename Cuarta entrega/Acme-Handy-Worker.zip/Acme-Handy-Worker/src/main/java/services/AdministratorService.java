/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.AdministratorRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Administrator;
import domain.Customer;
import domain.HandyWorker;
import domain.Message;

@Service
@Transactional
public class AdministratorService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private AdministratorRepository	administratorRepository;

	// Business repository -----------------------------------------------------

	@Autowired
	private MessageService			messageService;
	private ActorService			actorService;


	// Constructors -----------------------------------------------------------

	public AdministratorService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Administrator create() {
		Administrator result;

		result = new Administrator();

		return result;
	}

	public Collection<Administrator> findAll() {
		Collection<Administrator> result;

		result = this.administratorRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Administrator findOne(final int administratorId) {
		Administrator result;

		result = this.administratorRepository.findOne(administratorId);
		Assert.notNull(result);

		return result;
	}

	public Administrator save(final Administrator administrator) {
		Assert.notNull(administrator);

		Administrator result;

		result = this.administratorRepository.save(administrator);

		return result;
	}

	public void delete(final Administrator administrator) {
		Assert.notNull(administrator);
		Assert.isTrue(administrator.getId() != 0);

		//lo que dijo de que teniamos que comprobar si el que borraba su cuenta era el de la cuenta
		final UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.isTrue(administrator.getUserAccount().equals(userAccount));

		this.administratorRepository.delete(administrator);
	}

	// Other business methods -------------------------------------------------

	public void setMessageToAll(final Administrator administrator, final Message message) {
		Assert.notNull(administrator);
		Assert.isTrue(administrator.getId() != 0);

		//lo que dijo de que teniamos que comprobar si el que borraba su cuenta era el de la cuenta
		final UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.isTrue(administrator.getUserAccount().equals(userAccount));
		//comprobamos si el administrador que envia el mensaje es el mismo que lo crea
		Assert.isTrue(message.getSender().getId() == administrator.getId());

		for (final Actor actor : this.actorService.findAll()) {

			message.setSender(actor);
			this.messageService.save(message);

		}

	}

	public Collection<Double> ammsNumberFixUpTasksUser() {

		final Collection<Double> result = this.administratorRepository.ammsNumberFixUpTasksUser();

		return result;
	}

	public Collection<Double> ammsNumberApplicationsFixUpTask() {

		final Collection<Double> result = this.administratorRepository.ammsNumberApplicationsFixUpTask();

		return result;
	}

	public Collection<Double> ammsMaximumPriceFixUpTasks() {

		final Collection<Double> result = this.administratorRepository.ammsMaximumPriceFixUpTasks();

		return result;
	}

	public Collection<Double> ammsPriceOfferedApplications() {

		final Collection<Double> result = this.administratorRepository.ammsPriceOfferedApplications();

		return result;
	}

	public Double RatioPendingApplications() {

		Double result;

		result = this.administratorRepository.RatioPendingApplications();

		return result;
	}

	public Double RatioAcceptedApplications() {

		Double result;

		result = this.administratorRepository.RatioAcceptedApplications();

		return result;
	}

	public Double RatioRejectedApplications() {

		Double result;

		result = this.administratorRepository.RatioRejectedApplications();

		return result;
	}

	public Double RatioPendingCannotChangesStatus() {

		Double result;

		result = this.administratorRepository.RatioPendingApplications();

		return result;
	}

	public Collection<Customer> CustomerPublished10MoreFixUpTasks() {

		final Collection<Customer> result = this.administratorRepository.CustomerPublished10MoreFixUpTasks();

		return result;
	}
	public Collection<HandyWorker> handyPublished10MoreApplications() {

		final Collection<HandyWorker> result = this.administratorRepository.handyPublished10MoreApplications();

		return result;
	}

}
