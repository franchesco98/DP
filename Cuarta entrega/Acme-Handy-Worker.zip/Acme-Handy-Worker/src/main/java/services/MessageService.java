/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.MessageRepository;
import security.LoginService;
import domain.Actor;
import domain.Box;
import domain.Configuration;
import domain.Message;

@Service
@Transactional
public class MessageService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private MessageRepository		messageRepository;

	// Managed serviced ---------------------------------------

	@Autowired
	private ConfigurationService	configurationService;

	@Autowired
	private ActorService			actorService;

	@Autowired
	private BoxService				boxService;


	// Constructors -----------------------------------------------------------

	public MessageService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Message create() {

		Message result;
		result = new Message();

		result.setRecipients(new HashSet<Actor>());

		return result;
	}
	public Collection<Message> findAll() {
		Collection<Message> result;

		result = this.messageRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Message findOne(final int MessageId) {
		Message result;

		result = this.messageRepository.findOne(MessageId);
		Assert.notNull(result);

		return result;
	}

	public Message save(final Message message) {
		Assert.notNull(message);
		final int userAccountId = LoginService.getPrincipal().getId();
		Assert.isTrue(message.getSender().getId() == userAccountId);

		final Message result;

		final Collection<Box> boxes = message.getSender().getBoxes();

		//A�adir mensaje a la outbox del sender
		Box outBox = null;
		for (final Box box : boxes)
			if (box.getSystemBox() && box.getName().equals("out box"))
				outBox = box;

		final Collection<Message> outBoxMessages = outBox.getMessages();
		outBoxMessages.add(message);
		outBox.setMessages(outBoxMessages);
		//

		//Comprueba si el mensaje es spam
		this.setFlagSpam(message);
		if (message.getFlagSpam()) {
			Box spamBox = null;

			//Recorremos los recipient del mensaje pasado como par�metro
			for (final Actor recipient : message.getRecipients()) {
				//Recorremos las boxes del recipient
				for (final Box b : recipient.getBoxes())
					if (b.getSystemBox() && b.getName().equals("spam box"))
						spamBox = b;
				final Collection<Message> spamBoxMessages = spamBox.getMessages();

				//A�adir mensaje a la spam box de los recipients
				spamBoxMessages.add(message);
				spamBox.setMessages(spamBoxMessages);
			}
		} else {
			Box inBox = null;

			//Recorremos los recipients del mensaje pasado como par�metro
			for (final Actor recipient : message.getRecipients()) {
				//Recorremos las boxes del recipient
				for (final Box b : recipient.getBoxes())
					if (b.getSystemBox() && b.getName().equals("in box"))
						inBox = b;
				final Collection<Message> inBoxMessages = inBox.getMessages();

				//A�adir mensaje a las in boxes de los recipients
				inBoxMessages.add(message);
				inBox.setMessages(inBoxMessages);
			}
		}

		result = this.messageRepository.save(message);

		return result;
	}
	public void delete(final Message message) {
		Assert.notNull(message);
		Assert.isTrue(message.getId() != 0);

		final int idPrincipal = LoginService.getPrincipal().getId();
		final Actor principal = this.actorService.findOne(idPrincipal);
		Assert.isTrue(message.getSender().getId() == idPrincipal || message.getRecipients().contains(principal));

		final Collection<Box> principalBoxes = principal.getBoxes();
		Box principalTrashBox = null;

		for (final Box box : principalBoxes)
			if (box.getSystemBox() && box.getName().equals("trash box")) {
				principalTrashBox = box;
				break;
			}

		final Collection<Box> boxes = principal.getBoxes();

		for (final Box box : boxes)
			if (box.getMessages().contains(message) && box.equals(principalTrashBox)) {
				this.messageRepository.delete(message);
				break;
			} else if (box.getMessages().contains(message)) {
				final Collection<Message> messages = box.getMessages();
				messages.remove(message);
				box.setMessages(messages);

				final Collection<Message> trashBoxMessages = principalTrashBox.getMessages();
				trashBoxMessages.add(message);
				principalTrashBox.setMessages(trashBoxMessages);

				this.boxService.save(box);
				this.boxService.save(principalTrashBox);
			}
	}
	// Other business methods -------------------------------------------------

	public void setFlagSpam(final Message message) {
		Assert.notNull(message);
		Assert.isTrue(message.getId() != 0);

		final String body = message.getBody().toLowerCase();
		final String subject = message.getSubject().toLowerCase();
		final List<Configuration> configuration = new ArrayList<>(this.configurationService.findAll());
		final String[] spamWords = configuration.get(0).getSpamWords().split(",");

		for (final String spamWord : spamWords)
			if (subject.contains(spamWord.trim().toLowerCase()) || body.contains(spamWord.trim().toLowerCase()))
				message.setFlagSpam(true);
	}
}
