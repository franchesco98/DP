/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.AdministratorRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountService;
import domain.Actor;
import domain.Administrator;
import domain.Category;
import domain.Configuration;
import domain.Customer;
import domain.Endorsement;
import domain.HandyWorker;
import domain.Message;
import domain.Referee;
import domain.Warranty;

@Service
@Transactional
public class AdministratorService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private AdministratorRepository	administratorRepository;

	// Business repository -----------------------------------------------------

	@Autowired
	private MessageService			messageService;
	@Autowired
	private ActorService			actorService;
	@Autowired
	private WarrantyService			warrantyService;
	@Autowired
	private CategoryService			categoryService;
	@Autowired
	private RefereeService			refereeService;
	@Autowired
	private UserAccountService		userAccountService;
	@Autowired
	private CustomerService			customerService;
	@Autowired
	private HandyWorkerService		handyWorkerService;
	@Autowired
	private EndorserService			endorserService;
	@Autowired
	private ConfigurationService	configurationService;


	// Constructors -----------------------------------------------------------

	public AdministratorService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Administrator create() {

		Administrator result;
		result = new Administrator();

		final UserAccount userAccount = new UserAccount();
		final Authority authotity = new Authority();
		authotity.setAuthority(Authority.ADMIN);
		final Collection<Authority> authorities = new ArrayList<>();
		authorities.add(authotity);
		userAccount.setAuthorities(authorities);
		result.setUserAccount(userAccount);
		return result;
	}

	public Collection<Administrator> findAll() {
		Collection<Administrator> result;

		result = this.administratorRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Administrator findOne(final int administratorId) {
		Administrator result;

		result = this.administratorRepository.findOne(administratorId);
		Assert.notNull(result);

		return result;
	}

	public Administrator save(final Administrator administrator) {
		Assert.notNull(administrator);

		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Administrator result;

		if (!(administrator.getId() == 0)) {
			// comprobamos que el que la crear es un admin
			Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));
		} else {
			//comprobamos que es su cuenta
			Assert.isTrue(administrator.getUserAccount().equals(userAcount));
		}

		this.actorService.save(administrator);
		this.userAccountService.save(administrator.getUserAccount());

		result = this.administratorRepository.save(administrator);

		return result;
	}

	public void delete(final Administrator administrator) {
		Assert.notNull(administrator);
		Assert.isTrue(administrator.getId() != 0);

		//si el que borra su cuenta era el de la cuenta
		final UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.isTrue(administrator.getUserAccount().equals(userAccount));

		this.administratorRepository.delete(administrator);
	}

	// Other business methods -------------------------------------------------

	//R12.2

	public Collection<Warranty> listingAllWarrantiesByAdmin() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		return this.warrantyService.findAll();
	}

	public Warranty showWarrantyByAdminforId(final int warrantyId) {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		return this.warrantyService.findOne(warrantyId);
	}

	//R12.3

	public Collection<Category> listAllCategoriesByAdmin() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		return this.categoryService.findAll();
	}

	public Category showCategoryByAdminforId(final int CategoryId) {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		return this.categoryService.findOne(CategoryId);
	}

	//R 12.4

	public void messageToAll(final Message message) {
		Assert.notNull(message);

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//metemos en el sender el admin
		final Actor adminCreator = this.actorService.actorByUserAccount(userAcount);
		message.setSender(adminCreator);

		final Collection<Actor> allActors = this.actorService.findAll();
		//borramos a el mismo
		allActors.remove(adminCreator);
		message.setRecipients(allActors);

		this.messageService.save(message);
	}
	public Referee createNewReferee() {
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Referee res;
		res = this.refereeService.create();

		return res;

	}

	public Collection<Actor> listSuspiciousActor() {

		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Actor> suspiciousActors = this.administratorRepository.suspiciousActors();

		return suspiciousActors;

	}

	public void banActor(final Actor actor) {
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		if (actor.getIsSuspicious() == true) {
			actor.setIsBanned(true);
		}

		this.actorService.save(actor);
	}

	public void unbanActor(final Actor actor) {
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));
		if (actor.getIsBanned() == true) {
			actor.setIsBanned(false);
		}
		actor.setIsSuspicious(false);
		this.actorService.save(actor);
	}

	//R12.5

	public Collection<Double> ammsNumberFixUpTasksUser() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsNumberFixUpTasksUser();

		return result;
	}

	public Collection<Double> ammsNumberApplicationsFixUpTask() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsNumberApplicationsFixUpTask();

		return result;
	}

	public Collection<Double> ammsMaximumPriceFixUpTasks() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsMaximumPriceFixUpTasks();

		return result;
	}

	public Collection<Double> ammsPriceOfferedApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsPriceOfferedApplications();

		return result;
	}

	public Double RatioPendingApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		Double result;

		result = this.administratorRepository.RatioPendingApplications();

		return result;
	}

	public Double RatioAcceptedApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		Double result;

		result = this.administratorRepository.RatioAcceptedApplications();

		return result;
	}

	public Double RatioRejectedApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		Double result;

		result = this.administratorRepository.RatioRejectedApplications();

		return result;
	}

	public Double RatioPendingCannotChangesStatus() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		Double result;

		result = this.administratorRepository.RatioPendingApplications();

		return result;
	}

	public Collection<Customer> CustomerPublished10MoreFixUpTasks() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Customer> result = this.administratorRepository.CustomerPublished10MoreFixUpTasks();

		return result;
	}
	public Collection<HandyWorker> handyPublished10MoreApplications() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<HandyWorker> result = this.administratorRepository.handyPublished10MoreApplications();

		return result;
	}

	public Collection<Double> ammsNumberComplaintsFixUpTasks() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsNumberComplaintsFixUpTasks();

		return result;
	}
	public Collection<Double> ammsNumberNotesRefereeReport() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Double> result = this.administratorRepository.ammsNumberNotesRefereeReport();

		return result;
	}

	public Double RatioFixUpTasksComplaint() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		Double result;

		result = this.administratorRepository.RatioFixUpTasksComplaint();

		return result;
	}

	public Collection<Customer> TopThreeCustomersComplaints() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<Customer> result = this.administratorRepository.topThreeCustomersComplaints();

		return result;
	}
	public Collection<HandyWorker> TopThreeHandyWorkersComplaints() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		final Collection<HandyWorker> result = this.administratorRepository.topThreeHandyWorkersComplaints();

		return result;
	}

	//R50.1

	//sumo positivas-negativas/total

	public void computedScore() {

		//ver que el principal sea un admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//cogemos las palabras positivas y negativas en ambos idiomas
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);
		final String[] positiveWordsE = configuration.getPositiveWordsE().split(",");
		final String[] negativeWordsE = configuration.getNegativeWordsE().split(",");
		final String[] positiveWordsS = configuration.getPositiveWordsS().split(",");
		final String[] negativeWordsS = configuration.getNegativeWordsS().split(",");

		//para el customer		
		final Collection<Customer> allCustomers = this.customerService.findAll();

		for (final Customer customer : allCustomers) {

			final Collection<Endorsement> endorsementsRecived = this.endorserService.findEndorsementsRecipientByEndorserId(customer);

			Double countPositiveWordE = 0.0;
			Double countNegativeWordE = 0.0;
			Double countPositiveWordsS = 0.0;
			Double countNegativeWordsS = 0.0;

			for (final Endorsement endorsement : endorsementsRecived) {
				//comentarios de un endorsement
				final String[] comments = endorsement.getComments().split(";;");

				//compruebo las negative/positive words de cada coment
				for (final String comment : comments) {
					for (final String positiveWordE : positiveWordsE) {
						if (comment.contains(positiveWordE.trim())) {
							countPositiveWordE++;
						}
					}
					for (final String negativeWordE : negativeWordsE) {
						if (comment.contains(negativeWordE.trim())) {
							countNegativeWordE++;
						}
					}
					for (final String positiveWordS : positiveWordsS) {
						if (comment.contains(positiveWordS.trim())) {
							countPositiveWordsS++;
						}
					}
					for (final String negativeWordS : negativeWordsS) {
						if (comment.contains(negativeWordS.trim())) {
							countNegativeWordsS++;
						}

					}
				}
			}

			final Double score = (countPositiveWordE + countPositiveWordsS) - (countNegativeWordE + countNegativeWordsS) / (positiveWordsE.length + positiveWordsS.length + negativeWordsE.length + negativeWordsS.length);
			customer.setScore(score);
			this.endorserService.save(customer);
			this.customerService.save(customer);
		}
		//para el handy
		final Collection<HandyWorker> allHandy = this.handyWorkerService.findAll();

		for (final HandyWorker handy : allHandy) {

			final Collection<Endorsement> endorsementsRecived = this.endorserService.findEndorsementsRecipientByEndorserId(handy);

			Double countPositiveWordE = 0.0;
			Double countNegativeWordE = 0.0;
			Double countPositiveWordsS = 0.0;
			Double countNegativeWordsS = 0.0;

			for (final Endorsement endorsement : endorsementsRecived) {
				//comentarios de un endorsement
				final String[] comments = endorsement.getComments().split(";;");

				//compruebo las negative/positive words de cada coment
				for (final String comment : comments) {
					for (final String positiveWordE : positiveWordsE) {
						if (comment.contains(positiveWordE.trim())) {
							countPositiveWordE++;
						}
					}
					for (final String negativeWordE : negativeWordsE) {
						if (comment.contains(negativeWordE.trim())) {
							countNegativeWordE++;
						}
					}
					for (final String positiveWordS : positiveWordsS) {
						if (comment.contains(positiveWordS.trim())) {
							countPositiveWordsS++;
						}
					}
					for (final String negativeWordS : negativeWordsS) {
						if (comment.contains(negativeWordS.trim())) {
							countNegativeWordsS++;
						}

					}
				}
			}

			final Double score = (countPositiveWordE + countPositiveWordsS) - (countNegativeWordE + countNegativeWordsS) / (positiveWordsE.length + positiveWordsS.length + negativeWordsE.length + negativeWordsS.length);
			handy.setScore(score);
			this.endorserService.save(handy);
			this.handyWorkerService.save(handy);
		}

	}

	//R50.2

	//listing
	//English
	public List<String> listingPosivieWordE() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger el configuration
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		final String[] positiveWordsE = configuration.getPositiveWordsE().split(",");
		final List<String> res = new ArrayList<>();
		for (final String word : positiveWordsE) {
			res.add(word.trim());

		}

		return res;

	}

	public List<String> listingNegativeWordsE() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger el configuration
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		final String[] negativeWordsE = configuration.getNegativeWordsE().split(",");
		final List<String> res = new ArrayList<>();
		for (final String word : negativeWordsE) {
			res.add(word.trim());

		}

		return res;

	}

	//spanish

	public List<String> listingPosivieWordS() {

		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger el configuration
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		final String[] positiveWordsS = configuration.getPositiveWordsS().split(",");
		final List<String> res = new ArrayList<>();
		for (final String word : positiveWordsS) {
			res.add(word.trim());

		}

		return res;

	}

	public List<String> listingNegativeWordsS() {

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		final String[] negativeWordsS = configuration.getNegativeWordsS().split(",");
		final List<String> res = new ArrayList<>();
		for (final String word : negativeWordsS) {
			res.add(word.trim());

		}

		return res;

	}

	//creating
	//english	

	public Configuration creatingPosiveWordsE(final String newWorsd) {

		Assert.notNull(newWorsd);
		//comprobamos que la cadena sigue el patron adecuado
		Assert.isTrue(newWorsd.contains(","));
		Assert.isTrue(!newWorsd.replaceAll(",", "").trim().equals(""));
		Assert.isTrue(!newWorsd.trim().equals(""));

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		configuration.setPositiveWordsE(newWorsd);
		return this.configurationService.save(configuration);
	}

	public Configuration creatingNegativeWordsE(final String newWorsd) {

		Assert.notNull(newWorsd);
		//comprobamos que la cadena sigue el patron adecuado
		Assert.isTrue(newWorsd.contains(","));
		Assert.isTrue(!newWorsd.replaceAll(",", "").trim().equals(""));
		Assert.isTrue(!newWorsd.trim().equals(""));

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		configuration.setNegativeWordsE(newWorsd);
		return this.configurationService.save(configuration);
	}

	//spanish

	public Configuration creatingPosiveWordsS(final String newWorsd) {

		Assert.notNull(newWorsd);
		//comprobamos que la cadena sigue el patron adecuado
		Assert.isTrue(newWorsd.contains(","));
		Assert.isTrue(!newWorsd.replaceAll(",", "").trim().equals(""));
		Assert.isTrue(!newWorsd.trim().equals(""));

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		configuration.setPositiveWordsS(newWorsd);
		return this.configurationService.save(configuration);
	}

	public Configuration creatingNegativeWordsS(final String newWorsd) {

		Assert.notNull(newWorsd);
		//comprobamos que la cadena sigue el patron adecuado
		Assert.isTrue(newWorsd.contains(","));
		Assert.isTrue(!newWorsd.replaceAll(",", "").trim().equals(""));
		Assert.isTrue(!newWorsd.trim().equals(""));

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		configuration.setNegativeWordsS(newWorsd);
		return this.configurationService.save(configuration);
	}

	//updating

	//english	

	public String updatingPosiveWordE(final String newWord) {

		Assert.notNull(newWord);

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		//ponemos la newWord en el formato correcto
		newWord.replaceAll(",", "");
		newWord.trim();

		String res = configuration.getPositiveWordsE() + "," + newWord;
		//caso en el que la lista este vacia
		if (configuration.getNegativeWordsS().isEmpty()) {
			res.replaceAll(",", "");
			res = res + ",";
		}
		configuration.setPositiveWordsE(res);
		this.configurationService.save(configuration);

		return res;
	}

	public String updatingNegativeWordE(final String newWord) {

		Assert.notNull(newWord);

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		//ponemos la newWord en el formato correcto
		newWord.replaceAll(",", "");
		newWord.trim();

		String res = configuration.getNegativeWordsE() + "," + newWord;
		//caso en el que la lista este vacia
		if (configuration.getNegativeWordsS().isEmpty()) {
			res.replaceAll(",", "");
			res = res + ",";
		}
		configuration.setNegativeWordsE(res);
		this.configurationService.save(configuration);

		return res;
	}

	//spanish

	public String updatingPositiveWordS(final String newWord) {

		Assert.notNull(newWord);

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		//ponemos la newWord en el formato correcto
		newWord.replaceAll(",", "");
		newWord.trim();

		String res = configuration.getPositiveWordsS() + "," + newWord;
		//caso en el que la lista este vacia
		if (configuration.getNegativeWordsS().isEmpty()) {
			res.replaceAll(",", "");
			res = res + ",";
		}
		configuration.setPositiveWordsS(res);
		this.configurationService.save(configuration);

		return res;
	}

	public String updatingNegativeWordS(final String newWord) {

		Assert.notNull(newWord);

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		//ponemos la newWord en el formato correcto
		newWord.replaceAll(",", "");
		newWord.trim();

		String res = configuration.getNegativeWordsS() + "," + newWord;
		//caso en el que la lista este vacia
		if (configuration.getNegativeWordsS().isEmpty()) {
			res.replaceAll(",", "");
			res = res + ",";
		}
		configuration.setNegativeWordsS(res);
		this.configurationService.save(configuration);

		return res;
	}

	//deleting
	//english	

	public String deletingPosiveWordE(final String deleteWord) {

		Assert.notNull(deleteWord);

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		//ponemos la deleteWord en el formato correcto
		deleteWord.replaceAll(",", "");
		deleteWord.trim();

		final String res = configuration.getPositiveWordsE().replaceAll(deleteWord, "DELETE");
		res.replaceAll(",DELETE,", ",");
		res.replaceAll("DELETE,", "");
		res.replaceAll(",DELETE", "");
		configuration.setPositiveWordsE(res);
		this.configurationService.save(configuration);

		return res;
	}

	public String deletingNegativeWordE(final String deleteWord) {

		Assert.notNull(deleteWord);

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		//ponemos la deleteWord en el formato correcto
		deleteWord.replaceAll(",", "");
		deleteWord.trim();

		final String res = configuration.getNegativeWordsE().replaceAll(deleteWord, "DELETE");
		res.replaceAll(",DELETE,", ",");
		res.replaceAll("DELETE,", "");
		res.replaceAll(",DELETE", "");
		configuration.setNegativeWordsE(res);
		this.configurationService.save(configuration);

		return res;
	}

	//Spanish

	public String deletingPosiveWordS(final String deleteWord) {

		Assert.notNull(deleteWord);

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		//ponemos la deleteWord en el formato correcto
		deleteWord.replaceAll(",", "");
		deleteWord.trim();

		final String res = configuration.getPositiveWordsS().replaceAll(deleteWord, "DELETE");
		res.replaceAll(",DELETE,", ",");
		res.replaceAll("DELETE,", "");
		res.replaceAll(",DELETE", "");
		configuration.setPositiveWordsS(res);
		this.configurationService.save(configuration);

		return res;
	}

	public String deletingNegativeWordS(final String deleteWord) {

		Assert.notNull(deleteWord);

		//ver que el principal sea un admin
		//solo lo usan admin
		UserAccount userAcount;
		userAcount = LoginService.getPrincipal();
		Assert.isTrue(userAcount.getAuthorities().contains(Authority.ADMIN));

		//coger la configuracion
		final List<Configuration> aux = new ArrayList<>(this.configurationService.findAll());
		final Configuration configuration = aux.get(0);

		//ponemos la deleteWord en el formato correcto
		deleteWord.replaceAll(",", "");
		deleteWord.trim();

		final String res = configuration.getNegativeWordsS().replaceAll(deleteWord, "DELETE");
		res.replaceAll(",DELETE,", ",");
		res.replaceAll("DELETE,", "");
		res.replaceAll(",DELETE", "");
		configuration.setNegativeWordsS(res);
		this.configurationService.save(configuration);

		return res;
	}

}
