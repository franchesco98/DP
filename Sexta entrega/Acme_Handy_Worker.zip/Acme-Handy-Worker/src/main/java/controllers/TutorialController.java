/*
 * BoxController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.HandyWorkerService;
import services.SponsorShipService;
import services.TutorialService;
import domain.HandyWorker;
import domain.Tutorial;

@Controller
@RequestMapping("/tutorial")
public class TutorialController extends AbstractController {

	//Managed services
	@Autowired
	private TutorialService		tutorialService;

	@Autowired
	private HandyWorkerService	handyWorkerService;

	@Autowired
	private SponsorShipService	sponsorShipService;


	// Constructors -----------------------------------------------------------

	public TutorialController() {
		super();
	}

	// List ---------------------------------------------------------------		

	@RequestMapping(value = "/handy-worker/list", method = RequestMethod.GET)
	public ModelAndView handyWorkerList() {
		ModelAndView result;
		Collection<Tutorial> tutorials = null;

		final HandyWorker loggedHandyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();

		tutorials = this.tutorialService.listTutorialsByHandyWorker(loggedHandyWorker);
		result = new ModelAndView("tutorial/tutorialList");

		result.addObject("tutorials", tutorials);
		result.addObject("requestURI", "tutorial/handy-worker/list.do");
		result.addObject("toShow", false);

		return result;
	}

	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/handy-worker/create", method = RequestMethod.GET)
	public ModelAndView handyWorkerCreate() {
		final ModelAndView result;
		Tutorial tutorial;

		tutorial = this.tutorialService.create();
		result = this.createEditModelAndView(tutorial);
		return result;
	}

	// Edit ---------------------------------------------------------------		

	@RequestMapping(value = "/handy-worker/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int tutorialId) {
		final ModelAndView result;
		Tutorial tutorial;

		tutorial = this.tutorialService.findOne(tutorialId);
		Assert.notNull(tutorial);

		//Assert para comprobar que un actor no accede a edit box de otros actores
		Assert.isTrue(this.handyWorkerService.findHandyWorkerByPrincipal().getId() == tutorial.getHandyWorker().getId());

		result = this.createEditModelAndView(tutorial);
		return result;
	}

	// Save ---------------------------------------------------------------		
	@RequestMapping(value = "/handy-worker/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Tutorial tutorial, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(tutorial);
		else
			try {

				this.tutorialService.save(tutorial);

				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(tutorial, "tutorial.commit.error");
			}

		return result;
	}

	// Delete ---------------------------------------------------------------		
	@RequestMapping(value = "/handy-worker/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Tutorial tutorial, final BindingResult binding) {
		ModelAndView result;

		try {
			this.tutorialService.deleteTutorial(tutorial);
			result = new ModelAndView("redirect:list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(tutorial, "tutorial.commit.delete");
		}

		return result;
	}

	//	@RequestMapping(value = "/show", method = RequestMethod.GET)
	//	public ModelAndView show(@RequestParam final int tutorialId) {
	//		final ModelAndView result;
	//		Tutorial tutorial;
	//
	//		tutorial = this.tutorialService.findOne(tutorialId);
	//		Assert.notNull(tutorial);
	//
	//		final Collection<SponsorShip> sponsorships = this.sponsorShipService.findAll();
	//		SponsorShip[] sponsorshipsA = (SponsorShip) sponsorships.t;
	//
	//		result = this.createEditModelAndView(tutorial);
	//		return result;
	//	}
	// Ancillary Methods -----------------------------------------------------
	protected ModelAndView createEditModelAndView(final Tutorial tutorial) {
		ModelAndView result;

		result = this.createEditModelAndView(tutorial, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Tutorial tutorial, final String messageCode) {
		ModelAndView result;

		if (tutorial.getId() == 0)
			result = new ModelAndView("tutorial/tutorialCreate");
		else
			result = new ModelAndView("tutorial/tutorialEdit");

		result.addObject("tutorial", tutorial);
		result.addObject("message", messageCode);

		return result;
	}
}
