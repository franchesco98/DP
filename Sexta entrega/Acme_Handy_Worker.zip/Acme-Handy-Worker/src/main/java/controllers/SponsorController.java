/*
 * CustomerController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.BoxService;
import services.SponsorService;
import domain.Sponsor;

@Controller
@RequestMapping("/sponsor")
public class SponsorController extends AbstractController {

	//Managed services
	@Autowired
	private SponsorService	sponsorService;
	@Autowired
	private BoxService		boxService;


	// Constructors -----------------------------------------------------------

	public SponsorController() {
		super();
	}

	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		Sponsor sponsor;

		sponsor = this.sponsorService.create();

		result = this.createEditModelAndView(sponsor);

		return result;
	}

	// Save ---------------------------------------------------------------
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Sponsor sponsor, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {

			result = this.createEditModelAndView(sponsor);

			System.out.println(binding.hasErrors());
		} else
			try {

				this.sponsorService.save(sponsor);

				result = new ModelAndView("redirect:/security/login.do");
			} catch (final Throwable oops) {

				result = this.createEditModelAndView(sponsor, "sponsor.commit.error");
			}
		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int sponsorId) {
		ModelAndView result;
		Sponsor sponsor;

		sponsor = this.sponsorService.findOne(sponsorId);
		Assert.notNull(sponsor);

		result = this.createEditModelAndView(sponsor);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Sponsor sponsor) {
		ModelAndView result;

		result = this.createEditModelAndView(sponsor, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Sponsor sponsor, final String messageCode) {
		ModelAndView result;
		final String rol = "sponsor";
		final Boolean toShow = false;
		result = new ModelAndView("actor/edit");
		result.addObject("sponsor", sponsor);
		result.addObject("rol", rol);
		result.addObject("toShow", toShow);
		result.addObject("message", messageCode);

		return result;
	}
}
