
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.WarrantyService;
import domain.Warranty;

@Controller
@RequestMapping("/warranty")
public class WarrantyController {

	// Services ---------------------------------------------------------------

	@Autowired
	private WarrantyService	warrantyService;


	// Constructor ------------------------------------------------------------

	public WarrantyController() {
		super();
	}

	// List warranties --------------------------------------------------------
	@RequestMapping("/administrator/list")
	public ModelAndView show() {
		ModelAndView result;
		final Collection<Warranty> warranties = this.warrantyService.findAll();

		result = new ModelAndView("warranty/administrator/list");

		result.addObject("warranties", warranties);

		return result;
	}

	// Create warranty  -------------------------------------------------------

	@RequestMapping("/administrator/create")
	public ModelAndView create() {
		ModelAndView result;
		final Warranty warranty = this.warrantyService.create();

		result = new ModelAndView("warranty/administrator/create");
		result.addObject("warranty", warranty);

		result.addObject("toShow", false);

		return result;
	}

	// Show warranty ----------------------------------------------------------

	@RequestMapping("/administrator,handyworker,customer/show")
	public ModelAndView show(@RequestParam final int warrantyId) {
		ModelAndView result;
		final Warranty warranty = this.warrantyService.findOne(warrantyId);
		Assert.notNull(warranty);

		result = new ModelAndView("warranty/administrator/show");
		result.addObject("warranty", warranty);
		result.addObject("toShow", true);

		return result;
	}

	// Edit warranty ----------------------------------------------------------

	@RequestMapping("/administrator/edit")
	public ModelAndView edit(@RequestParam final int warrantyId) {
		ModelAndView result;
		final Warranty warranty = this.warrantyService.findOne(warrantyId);
		Assert.notNull(warranty);

		result = this.createEditModelAndView(warranty, null);

		return result;
	}

	// Save warranty ----------------------------------------------------------

	@RequestMapping(value = "/administrator/save", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Warranty warranty, final BindingResult binding, @RequestParam(defaultValue = "false") final String isFinal) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(warranty, null);
		else
			try {

				warranty.setIsFinal(new Boolean(isFinal));
				this.warrantyService.save(warranty);

				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {

				result = this.createEditModelAndView(warranty, "warranty.commit.error");
			}

		return result;
	}

	// Delete warranty --------------------------------------------------------

	@RequestMapping(value = "/administrator/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int warrantyId) {
		ModelAndView result;
		final Warranty warranty = this.warrantyService.findOne(warrantyId);

		this.warrantyService.delete(warranty);

		result = this.show();

		return result;
	}

	protected ModelAndView createEditModelAndView(final Warranty warranty, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("warranty/administrator/edit");
		result.addObject("warranty", warranty);

		result.addObject("toShow", false);
		result.addObject("message", messageCode);

		return result;
	}

}
