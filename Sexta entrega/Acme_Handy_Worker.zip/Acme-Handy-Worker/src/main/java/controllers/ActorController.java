
package controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import security.Authority;
import services.ActorService;
import services.RefereeService;
import domain.Actor;
import domain.Referee;

@Controller
@RequestMapping("/actor")
public class ActorController {

	@Autowired
	private ActorService	actorService;
	@Autowired
	private RefereeService	refereeService;


	public ActorController() {
		super();
	}

	@RequestMapping("/edit")
	public ModelAndView edit() {
		ModelAndView result;
		final Actor actor = this.actorService.findActorByPrincipal();

		result = this.createEditModelAndView(actor);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Actor actor) {
		return this.createEditModelAndView(actor, null);
	}

	protected ModelAndView createEditModelAndView(final Actor actor, final String messageCode) {
		ModelAndView result;
		String rol = "";
		final Authority actorAuthority = (Authority) actor.getUserAccount().getAuthorities().toArray()[0];
		result = new ModelAndView("actor/edit");

		if (actorAuthority.equals("REFEREE")) {
			rol = "referee";
			final Referee referee = this.refereeService.findRefereeByPrincipal();
			result.addObject("referee", referee);
		}

		//		result.addObject("actor", actor);
		result.addObject("rol", rol);

		//result.addObject("message", messageCode);
		result.addObject("toShow", false);
		result.addObject("create", false);

		return result;
	}
}
