
package controllers;

import java.util.Collection;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.EducationRecordService;
import services.HandyWorkerService;
import domain.Curriculum;
import domain.EducationRecord;

@Controller
@RequestMapping("/educationrecord/handyworker")
public class EducationRecordController extends AbstractController {

	// Services -------------------------------------

	@Autowired
	private EducationRecordService	educationRecordService;
	@Autowired
	private HandyWorkerService		handyWorkerService;


	// Constructors ---------------------------------------

	public EducationRecordController() {
		super();
	}

	// Creation --------------------------------------------

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		EducationRecord educationRecord;

		educationRecord = this.educationRecordService.create();
		result = this.createEditModelAndView(educationRecord);

		return result;
	}

	// Edition -------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int educationRecordId) {
		ModelAndView result;
		EducationRecord educationRecord;

		educationRecord = this.educationRecordService.findOne(educationRecordId);
		Assert.notNull(educationRecord);
		result = this.createEditModelAndView(educationRecord);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final EducationRecord educationRecord, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = this.createEditModelAndView(educationRecord);
			System.out.println(binding.hasErrors());
		} else
			try {
				this.educationRecordService.save(educationRecord);
				result = new ModelAndView("redirect:listAll.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(educationRecord, "educationRecord.commit.error");
			}
		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final EducationRecord educationRecord, final BindingResult binding) {
		ModelAndView result;

		try {
			this.educationRecordService.delete(educationRecord);
			result = new ModelAndView("redirect:listAll.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(educationRecord, "educationRecord.commit.error");
		}

		return result;
	}

	@RequestMapping(value = "/listAll", method = RequestMethod.GET)
	public ModelAndView List() {
		ModelAndView result;
		Collection<EducationRecord> educationRecords;

		Curriculum curriculum;
		curriculum = this.handyWorkerService.listingCurriculumCreatedByHandyWorkerPrincipal();
		educationRecords = curriculum.getEducationRecords();
		Assert.notNull(curriculum);
		result = new ModelAndView("educationRecord/DisplayListEducationRecord");
		result.addObject("educationRecords", educationRecords);

		return result;
	}
	// Ancillary methods -----------------------------------------

	protected ModelAndView createEditModelAndView(final EducationRecord educationRecord) {
		ModelAndView result;

		result = this.createEditModelAndView(educationRecord, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final EducationRecord educationRecord, final String messageCode) {
		ModelAndView result;
		String diplomaTitle, institution, attachment, comment;
		Date startDate, endDate;

		diplomaTitle = educationRecord.getTitle();
		institution = educationRecord.getInstitution();
		attachment = educationRecord.getLink();
		startDate = educationRecord.getStartDate();
		endDate = educationRecord.getEndDate();
		comment = educationRecord.getComment();

		result = new ModelAndView("educationRecord/edit");
		result.addObject("educationRecord", educationRecord);
		result.addObject("diplomaTitle", diplomaTitle);
		result.addObject("institution", institution);
		result.addObject("attachment", attachment);
		result.addObject("startDate", startDate);
		result.addObject("endDate", endDate);
		result.addObject("comments", comment);

		result.addObject("message", messageCode);

		return result;
	}
}
