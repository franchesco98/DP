/*
 * BoxController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.LoginService;
import services.HandyWorkerService;
import services.SectionService;
import services.TutorialService;
import domain.Section;
import domain.Tutorial;

@Controller
@RequestMapping("/section")
public class SectionController extends AbstractController {

	//Managed services
	@Autowired
	private HandyWorkerService	handyWorkerService;

	@Autowired
	private TutorialService		tutorialService;

	@Autowired
	private SectionService		sectionService;


	// Constructors -----------------------------------------------------------

	public SectionController() {
		super();
	}

	// List ---------------------------------------------------------------		

	@RequestMapping(value = "/handy-worker/list", method = RequestMethod.GET)
	public ModelAndView listByCreator(@RequestParam final int tutorialId) {
		ModelAndView result;
		Collection<Section> sections = null;

		final Tutorial tutorial = this.tutorialService.findOne(tutorialId);

		//Assert para comprobar que un actor no acceda a sections de otros HW
		Assert.isTrue(tutorial.getHandyWorker().getId() == this.handyWorkerService.findHandyWorkerByPrincipal().getId());

		sections = this.tutorialService.getSectionsByTutorial(tutorial);

		result = new ModelAndView("section/sectionList");

		result.addObject("sections", sections);
		result.addObject("tutorial", tutorial);
		result.addObject("toShow", false);

		result.addObject("requestURI", "section/handy-worker/list.do");

		return result;
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int tutorialId) {
		ModelAndView result;
		Collection<Section> sections = null;

		final Tutorial tutorial = this.tutorialService.findOne(tutorialId);

		sections = this.tutorialService.getSectionsByTutorial(tutorial);

		result = new ModelAndView("section/sectionList");

		//Se mete dentro de un bloque try/catch porque si no hay nadie logueado al obtener getPrincipal se eleva excepcion
		try {
			if (LoginService.getPrincipal().getId() == tutorial.getHandyWorker().getUserAccount().getId())
				result.addObject("toShow", false);
			else
				result.addObject("toShow", true);
		} catch (final Exception e) {
			result.addObject("toShow", true);
		}

		result.addObject("sections", sections);
		result.addObject("tutorial", tutorial);

		result.addObject("requestURI", "section/list.do");

		return result;
	}

	// Create ---------------------------------------------------------------		

	@RequestMapping(value = "/handy-worker/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int tutorialId) {
		final ModelAndView result;
		Section section;
		Tutorial tutorial;

		tutorial = this.tutorialService.findOne(tutorialId);
		Assert.notNull(tutorial);

		section = this.sectionService.create();
		section.setTutorial(tutorial);
		//Por defecto, asignamos de number el numero de sections de ese tutorial + 1
		section.setNumber(this.tutorialService.getSectionsByTutorial(tutorial).size() + 1);
		result = this.createEditModelAndView(section);

		result.addObject("toShow", false);

		return result;
	}

	// Show---------------------------------------------------------------		
	@RequestMapping(value = "/show", method = RequestMethod.GET)
	public ModelAndView show(@RequestParam final int tutorialId, @RequestParam final int sectionId) {
		final ModelAndView result;
		Tutorial tutorial;
		Section section;

		tutorial = this.tutorialService.findOne(tutorialId);
		Assert.notNull(tutorial);
		section = this.sectionService.findOne(sectionId);
		Assert.notNull(section);

		//Assert para comprobar que la section pertenece a dicho tutorial
		Assert.isTrue(section.getTutorial().getId() == tutorial.getId());

		result = this.createEditModelAndView(section);

		if (section.getPictures() != null) {
			Collection<String> picturesC = new ArrayList<>();
			picturesC = this.tutorialService.splitPictures(section.getPictures());
			result.addObject("pictures", picturesC);
		}

		result.addObject("toShow", true);

		return result;
	}

	// Edit---------------------------------------------------------------		
	@RequestMapping(value = "/handy-worker/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int tutorialId, @RequestParam final int sectionId) {
		final ModelAndView result;
		Tutorial tutorial;
		Section section;

		tutorial = this.tutorialService.findOne(tutorialId);
		Assert.notNull(tutorial);
		section = this.sectionService.findOne(sectionId);
		Assert.notNull(section);

		//Assert para comprobar que la section pertenece a dicho tutorial
		//Comprobar que el tutorial pertenece al HW logueado
		Assert.isTrue(section.getTutorial().getId() == tutorial.getId());
		Assert.isTrue(this.handyWorkerService.findHandyWorkerByPrincipal().getId() == tutorial.getHandyWorker().getId());

		result = this.createEditModelAndView(section);

		result.addObject("toShow", false);

		return result;
	}

	// Save ---------------------------------------------------------------		
	@RequestMapping(value = "/handy-worker/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Section section, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(section);
		else
			try {
				this.sectionService.save(section);
				final String redirect = "redirect:list.do?tutorialId=" + section.getTutorial().getId();
				result = new ModelAndView(redirect);
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(section, "section.commit.error");
			}

		return result;
	}

	// Delete ---------------------------------------------------------------		
	@RequestMapping(value = "/handy-worker/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Section section, final BindingResult binding) {
		ModelAndView result;
		try {
			this.sectionService.delete(section);

			final String redirect = "redirect:list.do?tutorialId=" + section.getTutorial().getId();
			result = new ModelAndView(redirect);
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(section, "section.commit.delete");
			result.addObject("toShow", false);
		}

		return result;
	}

	// Ancillary Methods -----------------------------------------------------
	protected ModelAndView createEditModelAndView(final Section section) {
		ModelAndView result;

		result = this.createEditModelAndView(section, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Section section, final String messageCode) {
		ModelAndView result;

		if (section.getId() == 0)
			result = new ModelAndView("section/sectionCreate");
		else
			result = new ModelAndView("section/sectionEdit");

		result.addObject("section", section);
		result.addObject("message", messageCode);

		return result;
	}
}
