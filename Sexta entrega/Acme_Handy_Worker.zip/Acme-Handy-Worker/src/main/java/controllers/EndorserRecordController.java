
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.EndorserRecordService;
import services.HandyWorkerService;
import domain.Curriculum;
import domain.EndorserRecord;

@Controller
@RequestMapping("/endorserrecord/handyworker")
public class EndorserRecordController extends AbstractController {

	// Services -------------------------------------

	@Autowired
	private EndorserRecordService	endorserRecordService;
	@Autowired
	private HandyWorkerService		handyWorkerService;


	// Constructors ---------------------------------------

	public EndorserRecordController() {
		super();
	}

	// Creation --------------------------------------------

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		EndorserRecord endorserRecord;

		endorserRecord = this.endorserRecordService.create();
		result = this.createEditModelAndView(endorserRecord);

		return result;
	}

	// Edition -------------------------------------------------

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int endorserRecordId) {
		ModelAndView result;
		EndorserRecord endorserRecord;

		endorserRecord = this.endorserRecordService.findOne(endorserRecordId);
		Assert.notNull(endorserRecord);
		result = this.createEditModelAndView(endorserRecord);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final EndorserRecord endorserRecord, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(endorserRecord);
		else
			try {
				this.endorserRecordService.save(endorserRecord);
				result = new ModelAndView("redirect:listAll.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(endorserRecord, "endorserRecord.commit.error");
			}
		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final EndorserRecord endorserRecord, final BindingResult binding) {
		ModelAndView result;

		try {
			this.endorserRecordService.delete(endorserRecord);
			result = new ModelAndView("redirect:listAll.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(endorserRecord, "endorserRecord.commit.error");
		}

		return result;
	}
	@RequestMapping(value = "/listAll", method = RequestMethod.GET)
	public ModelAndView List() {
		ModelAndView result;
		Collection<EndorserRecord> endorserRecords;

		Curriculum curriculum;
		curriculum = this.handyWorkerService.listingCurriculumCreatedByHandyWorkerPrincipal();
		endorserRecords = curriculum.getEndorserRecords();
		Assert.notNull(curriculum);
		result = new ModelAndView("endorserRecord/DisplayListEndorserRecord");
		result.addObject("endorserRecords", endorserRecords);

		return result;
	}

	// Ancillary methods -----------------------------------------

	protected ModelAndView createEditModelAndView(final EndorserRecord endorserRecord) {
		ModelAndView result;

		result = this.createEditModelAndView(endorserRecord, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final EndorserRecord endorserRecord, final String messageCode) {
		ModelAndView result;
		String fullName, email, phoneNumber, linkedInProfile, comment;

		fullName = endorserRecord.getFullName();

		email = endorserRecord.getEmail();
		phoneNumber = endorserRecord.getPhoneNumber();
		linkedInProfile = endorserRecord.getLinkedinLink();
		comment = endorserRecord.getComment();

		result = new ModelAndView("endorserRecord/edit");
		result.addObject("endorserRecord", endorserRecord);
		result.addObject("fullName", fullName);

		result.addObject("email", email);
		result.addObject("phoneNumber", phoneNumber);
		result.addObject("linkedInProfile", linkedInProfile);
		result.addObject("comment", comment);

		result.addObject("message", messageCode);

		return result;
	}
}
