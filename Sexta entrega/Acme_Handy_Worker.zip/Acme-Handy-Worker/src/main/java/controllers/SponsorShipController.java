
package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.SponsorShipService;
import domain.SponsorShip;

@Controller
@RequestMapping("/sponsorship")
public class SponsorShipController {

	@Autowired
	private SponsorShipService	sponsorShipService;


	public SponsorShipController() {
		super();
	}

	@RequestMapping("/sponsor/list")
	public ModelAndView list() {
		ModelAndView result;
		final Collection<SponsorShip> sponsorships = this.sponsorShipService.findPrincipalSponsorships();
		result = new ModelAndView("sponsorship/sponsor/list");
		result.addObject("sponsorships", sponsorships);

		return result;
	}

	@RequestMapping("/sponsor/create")
	public ModelAndView create() {
		ModelAndView result;
		final SponsorShip sponsorship = this.sponsorShipService.create();

		result = new ModelAndView("sponsorship/sponsor/create");
		result.addObject("sponsorship", sponsorship);
		result.addObject("toShow", false);
		result.addObject("create", true);

		return result;
	}

	@RequestMapping(value = "/sponsor/show", method = RequestMethod.GET)
	public ModelAndView show(@RequestParam final int sponsorshipId) {
		ModelAndView result;
		final SponsorShip sponsorship = this.sponsorShipService.findOne(sponsorshipId);

		result = new ModelAndView("sponsorship/sponsor/show");
		result.addObject("sponsorship", sponsorship);
		result.addObject("toShow", true);
		result.addObject("create", false);

		return result;
	}

	@RequestMapping(value = "/sponsor/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int sponsorshipId) {
		final ModelAndView result;
		final SponsorShip sponsorship = this.sponsorShipService.findOne(sponsorshipId);

		result = this.createEditModelAndView(sponsorship, null);

		return result;
	}
	@RequestMapping(value = "/sponsor/save", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final SponsorShip sponsorship, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = this.createEditModelAndView(sponsorship, null);
			System.out.println(binding);
		} else
			try {
				this.sponsorShipService.save(sponsorship);

				result = new ModelAndView("redirect:list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(sponsorship, "sponsor.commit.error");
			}

		return result;
	}

	@RequestMapping(value = "/sponsor/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int sponsorshipId) {
		ModelAndView result;
		final SponsorShip sponsorship = this.sponsorShipService.findOne(sponsorshipId);

		this.sponsorShipService.delete(sponsorship);

		result = this.list();

		return result;
	}

	protected ModelAndView createEditModelAndView(final SponsorShip sponsorship, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("sponsorship/sponsor/edit");
		result.addObject("sponsorship", sponsorship);

		result.addObject("toShow", false);
		result.addObject("create", false);
		result.addObject("message", messageCode);

		return result;
	}

}
