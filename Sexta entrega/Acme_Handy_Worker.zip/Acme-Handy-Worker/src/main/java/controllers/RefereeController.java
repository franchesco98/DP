
package controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.RefereeService;
import domain.Referee;

@Controller
@RequestMapping("/referee")
public class RefereeController {

	// Services ---------------------------------------------------------------

	@Autowired
	private RefereeService	refereeService;


	// Constructor ------------------------------------------------------------

	public RefereeController() {
		super();
	}

	// Create referee ---------------------------------------------------------

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView createReferee() {
		ModelAndView result;
		final Referee referee = this.refereeService.create();

		result = new ModelAndView("referee/create");

		result.addObject("referee", referee);
		result.addObject("rol", "referee");
		result.addObject("toShow", false);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit() {
		ModelAndView result;
		final Referee principal = this.refereeService.findRefereeByPrincipal();

		result = this.createEditModelAndView(principal);

		return result;
	}

	// Save referee -----------------------------------------------------------
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid @ModelAttribute("referee") final Referee referee, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = this.createEditModelAndView(referee, null);
			System.out.println(binding);
		} else
			try {

				this.refereeService.save(referee);

				result = new ModelAndView("redirect:/welcome/index.do");
			} catch (final Throwable oops) {
				for (final StackTraceElement s : oops.getStackTrace()) {
					System.out.println(s);
					System.out.println(referee.getUserAccount().getPassword());
				}
				result = this.createEditModelAndView(referee, "referee.commit.error");
			}

		return result;
	}

	protected ModelAndView createEditModelAndView(final Referee referee) {
		return this.createEditModelAndView(referee, null);
	}

	protected ModelAndView createEditModelAndView(final Referee referee, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("referee/create");
		result.addObject("referee", referee);
		result.addObject("rol", "referee");

		result.addObject("message", messageCode);
		result.addObject("toShow", false);

		return result;
	}

}
