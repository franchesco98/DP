/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.TutorialRepository;
import domain.HandyWorker;
import domain.Section;
import domain.Tutorial;

@Service
@Transactional
public class TutorialService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private TutorialRepository	tutorialRepository;

	@Autowired
	private HandyWorkerService	handyWorkerService;

	@Autowired
	private SectionService		sectionService;


	// Constructors -----------------------------------------------------------

	public TutorialService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Tutorial create() {
		Tutorial result;

		result = new Tutorial();

		result.setMoment(new Date());
		result.setHandyWorker(this.handyWorkerService.findHandyWorkerByPrincipal());
		return result;
	}

	public Collection<Tutorial> findAll() {
		Collection<Tutorial> result;

		result = this.tutorialRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Tutorial findOne(final int tutorialId) {
		Assert.notNull(tutorialId);
		Tutorial result;

		result = this.tutorialRepository.findOne(tutorialId);
		Assert.notNull(result);

		return result;
	}

	public Tutorial save(final Tutorial tutorial) {
		Assert.notNull(tutorial);

		Tutorial result;

		//comprobar que ese tutorial es del handy	
		Assert.isTrue(tutorial.getHandyWorker().getId() == this.handyWorkerService.findHandyWorkerByPrincipal().getId());

		if (tutorial.getId() == 0)
			tutorial.setMoment(new Date());

		result = this.tutorialRepository.save(tutorial);
		return result;

	}
	public void delete(final Tutorial tutorial) {
		Assert.notNull(tutorial);

		this.tutorialRepository.delete(tutorial);
	}
	// Other business methods -------------------------------------------------

	public Collection<Section> getSectionsByTutorial(final Tutorial tutorial) {
		Assert.notNull(tutorial);

		return this.tutorialRepository.findSectionByTutorial(tutorial.getId());
	}

	public Collection<Tutorial> listTutorialsByHandyWorker(final HandyWorker handyWorker) {
		Assert.notNull(handyWorker);

		return this.tutorialRepository.findTutorialsByHandyWorkerId(handyWorker.getId());
	}

	public void deleteTutorial(final Tutorial tutorial) {
		Assert.notNull(tutorial);

		//comprobar que ese tutorial es del handy	
		Assert.isTrue(tutorial.getHandyWorker().getId() == this.handyWorkerService.findHandyWorkerByPrincipal().getId());

		//Eliminar sus sections
		for (final Section section : this.getSectionsByTutorial(tutorial))
			this.sectionService.delete(section);

		//TODO �Sponsorship de tutorial?

		//Eliminar el tutorial
		this.delete(tutorial);
	}

}
