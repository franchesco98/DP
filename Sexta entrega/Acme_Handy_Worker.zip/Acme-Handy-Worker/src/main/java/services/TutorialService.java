/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.TutorialRepository;
import domain.HandyWorker;
import domain.Section;
import domain.Tutorial;

@Service
@Transactional
public class TutorialService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private TutorialRepository		tutorialRepository;

	@Autowired
	private HandyWorkerService		handyWorkerService;

	@Autowired
	private SectionService			sectionService;

	@Autowired
	private ConfigurationService	configurationService;


	// Constructors -----------------------------------------------------------

	public TutorialService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Tutorial create() {
		Tutorial result;

		result = new Tutorial();

		result.setMoment(new Date());
		result.setHandyWorker(this.handyWorkerService.findHandyWorkerByPrincipal());
		return result;
	}

	public Collection<Tutorial> findAll() {
		Collection<Tutorial> result;

		result = this.tutorialRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Tutorial findOne(final int tutorialId) {
		Assert.notNull(tutorialId);
		Tutorial result;

		result = this.tutorialRepository.findOne(tutorialId);
		Assert.notNull(result);

		return result;
	}

	public Tutorial save(final Tutorial tutorial) {
		Assert.notNull(tutorial);

		Tutorial result;

		//comprobar que ese tutorial es del handy	
		Assert.isTrue(tutorial.getHandyWorker().getId() == this.handyWorkerService.findHandyWorkerByPrincipal().getId());

		if (tutorial.getId() == 0)
			tutorial.setMoment(new Date());

		//		if(tutorial.getPictures() != null){
		//			final Collection<String> pictures = this.splitPictures(tutorial.getPictures());
		//			final URLValidator val = new URLValidator();
		//			for (final String picture : pictures)
		//				Assert.isTrue(val.isValid(picture, arg1));
		//		}

		this.configurationService.checkContainsSpamWord(tutorial.getTitle());
		this.configurationService.checkContainsSpamWord(tutorial.getSummary());
		this.configurationService.checkContainsSpamWord(tutorial.getPictures());

		result = this.tutorialRepository.save(tutorial);
		return result;

	}
	public void delete(final Tutorial tutorial) {
		Assert.notNull(tutorial);

		this.tutorialRepository.delete(tutorial);
	}
	// Other business methods -------------------------------------------------

	public Collection<Section> getSectionsByTutorial(final Tutorial tutorial) {
		Assert.notNull(tutorial);

		return this.tutorialRepository.findSectionByTutorial(tutorial.getId());
	}

	public Collection<Tutorial> listTutorialsByHandyWorker(final HandyWorker handyWorker) {
		Assert.notNull(handyWorker);

		return this.tutorialRepository.findTutorialsByHandyWorkerId(handyWorker.getId());
	}

	public void deleteTutorial(final Tutorial tutorial) {
		Assert.notNull(tutorial);

		//comprobar que ese tutorial es del handy	
		Assert.isTrue(tutorial.getHandyWorker().getId() == this.handyWorkerService.findHandyWorkerByPrincipal().getId());

		//Eliminar sus sections
		for (final Section section : this.getSectionsByTutorial(tutorial))
			this.sectionService.delete(section);

		//Eliminar el tutorial
		this.delete(tutorial);
	}

	public Collection<String> splitPictures(final String pictures) {
		Assert.notNull(pictures);
		final Collection<String> picturesC = new ArrayList<>();
		final String[] picturesA = pictures.split(";;");
		for (final String picture : picturesA)
			picturesC.add(picture);
		return picturesC;
	}

}
