/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.SponsorRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountService;
import domain.CreditCard;
import domain.Sponsor;

@Service
@Transactional
public class SponsorService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private SponsorRepository		sponsorRepository;
	@Autowired
	private ActorService			actorService;

	@Autowired
	private UserAccountService		userAccountService;
	@Autowired
	private BoxService				boxService;
	@Autowired
	private ConfigurationService	configurationService;


	// Constructors -----------------------------------------------------------

	public SponsorService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Sponsor create() {
		Sponsor result;

		result = new Sponsor();

		UserAccount userAccount;
		userAccount = this.userAccountService.create();
		Authority authority;
		authority = new Authority();
		authority.setAuthority(Authority.SPONSOR);
		userAccount.addAuthority(authority);

		result.setUserAccount(userAccount);
		result.setBoxes(this.boxService.originalBoxes());
		return result;
	}

	public Collection<Sponsor> findAll() {
		Collection<Sponsor> result;

		result = this.sponsorRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Sponsor findOne(final int sponsorId) {
		Sponsor result;

		result = this.sponsorRepository.findOne(sponsorId);
		Assert.notNull(result);

		return result;
	}

	public Sponsor save(final Sponsor sponsor) {
		Assert.notNull(sponsor);
		Assert.notNull(sponsor.getUserAccount().getUsername());
		Assert.notNull(sponsor.getUserAccount().getPassword());

		//comprobamos que no nos han dado cadenas vacias en los at opcionales
		if (sponsor.getMiddleName() != null)
			Assert.isTrue(!(sponsor.getMiddleName().trim().equals("")));

		if (sponsor.getAddress() != null)
			Assert.isTrue(!(sponsor.getAddress().trim().equals("")));

		final Sponsor result;
		UserAccount sponsorUserAccountSaved;

		this.configurationService.checkContainsSpamWord(sponsor.getAddress());
		this.configurationService.checkContainsSpamWord(sponsor.getName());
		this.configurationService.checkContainsSpamWord(sponsor.getMiddleName());
		this.configurationService.checkContainsSpamWord(sponsor.getEmail());
		this.configurationService.checkContainsSpamWord(sponsor.getPhoto());
		this.configurationService.checkContainsSpamWord(sponsor.getSurname());
		this.configurationService.checkContainsSpamWord(sponsor.getUserAccount().getUsername());

		final Md5PasswordEncoder hash = new Md5PasswordEncoder();
		String md5;

		md5 = hash.encodePassword(sponsor.getUserAccount().getPassword(), null);
		sponsor.getUserAccount().setPassword(md5);

		sponsorUserAccountSaved = this.userAccountService.save(sponsor.getUserAccount());
		sponsor.setUserAccount(sponsorUserAccountSaved);

		if (sponsor.getId() == 0) {

			sponsor.getUserAccount().setAccountNonLocked(true);
			sponsor.setIsSuspicious(false);

		} else {

			final UserAccount userAccount;
			userAccount = LoginService.getPrincipal();
			Assert.isTrue(sponsor.getUserAccount().equals(userAccount));
		}

		result = this.sponsorRepository.save(sponsor);
		return result;
	}

	// Other business methods -------------------------------------------------

	public Sponsor findSponsorByPrincipal() {
		Sponsor result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.findByUserAccount(userAccount);
		Assert.notNull(result);

		return result;

	}

	public Sponsor findByUserAccount(final UserAccount userAccount) {
		Assert.notNull(userAccount);

		Sponsor result;

		result = this.sponsorRepository.findByUserAccountId(userAccount.getId());

		return result;
	}

	public Collection<CreditCard> getCreditCardsBySponsorId(final int sponsorId) {

		return this.sponsorRepository.findCreditCardsBySponsorId(sponsorId);
	}

}
