
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.PersonalRecordRepository;
import domain.Curriculum;
import domain.HandyWorker;
import domain.PersonalRecord;

@Service
@Transactional
public class PersonalRecordService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private PersonalRecordRepository	personalRecordRepository;
	@Autowired
	private HandyWorkerService			handyWorkerService;
	@Autowired
	private CurriculumService			curriculumService;
	@Autowired
	private ConfigurationService		configurationService;


	// Constructors -----------------------------------------------------------

	public PersonalRecordService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public PersonalRecord create() {
		PersonalRecord result;

		result = new PersonalRecord();

		return result;
	}

	public Collection<PersonalRecord> findAll() {
		Collection<PersonalRecord> result;

		result = this.personalRecordRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public PersonalRecord findOne(final int personalRecordId) {
		PersonalRecord result;

		result = this.personalRecordRepository.findOne(personalRecordId);
		System.out.println(result);
		Assert.notNull(result);

		return result;
	}

	public PersonalRecord save(final PersonalRecord personalRecord) {
		Assert.notNull(personalRecord);

		PersonalRecord result;
		HandyWorker handyWorker;
		Curriculum curriculum;

		handyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();
		curriculum = handyWorker.getCurriculum();
		this.configurationService.checkContainsSpamWord(personalRecord.getEmail());
		this.configurationService.checkContainsSpamWord(personalRecord.getFullName());
		this.configurationService.checkContainsSpamWord(personalRecord.getPhoneNumber());
		this.configurationService.checkContainsSpamWord(personalRecord.getPhoto());
		this.configurationService.checkContainsSpamWord(personalRecord.getUrlLinkedin());
		result = this.personalRecordRepository.save(personalRecord);
		curriculum.setPersonalRecord(personalRecord);
		this.curriculumService.save(curriculum);

		return result;
	}

	public void delete(final PersonalRecord personalRecord) {
		Assert.notNull(personalRecord);
		Assert.isTrue(personalRecord.getId() != 0);

		this.personalRecordRepository.delete(personalRecord);
	}

}
