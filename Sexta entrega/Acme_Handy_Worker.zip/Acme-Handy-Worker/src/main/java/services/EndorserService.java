/*
 * ActorService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.EndorserRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Customer;
import domain.Endorsement;
import domain.Endorser;
import domain.HandyWorker;

@Service
@Transactional
public class EndorserService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private EndorserRepository	endorserRepository;
	@Autowired
	private EndorsementService	endorsementService;
	@Autowired
	private CustomerService		customerService;
	@Autowired
	private HandyWorkerService	handyWorkerService;
	@Autowired
	private BoxService			boxService;


	// Supporting services ----------------------------------------------------

	// Constructors -----------------------------------------------------------

	public EndorserService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public Collection<Endorser> findAll() {
		Collection<Endorser> result;

		result = this.endorserRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public Actor findOne(final int endorserId) {
		Assert.isTrue(endorserId != 0);

		Actor result;

		result = this.endorserRepository.findOne(endorserId);
		Assert.notNull(result);

		return result;
	}

	public Actor save(final Endorser endorser) {
		Assert.notNull(endorser);
		Assert.notNull(endorser.getUserAccount().getUsername());
		Assert.notNull(endorser.getUserAccount().getPassword());

		//comprobamos que no nos han dado cadenas vacias en los at opcionales
		if (endorser.getMiddleName() != null)
			Assert.isTrue(!(endorser.getMiddleName().trim().equals("")));

		if (endorser.getAddress() != null)
			Assert.isTrue(!(endorser.getAddress().trim().equals("")));

		Endorser result;

		if (endorser.getId() == 0) {

			endorser.setBoxes(this.boxService.originalBoxes());
			endorser.getUserAccount().setAccountNonLocked(true);
			endorser.setIsSuspicious(false);

			endorser.setScore(0.0);
			result = this.endorserRepository.save(endorser);
		} else {
			int idPrincipal;
			idPrincipal = LoginService.getPrincipal().getId();
			Assert.isTrue(idPrincipal == endorser.getId());
			result = this.endorserRepository.save(endorser);
		}

		return result;
	}

	public void delete(final Endorser endorser) {
		Assert.notNull(endorser);
		Assert.isTrue(endorser.getId() != 0);
		Assert.isTrue(this.endorserRepository.exists(endorser.getId()));
		//comprobar que el endorser no tenga endorsement
		Assert.isTrue(this.endorserRepository.findEndorsementsByEndorserId(endorser.getId()).size() == 0);

		this.endorserRepository.delete(endorser);
	}

	// Other business methods -------------------------------------------------
	public Endorser findEndorserByPrincipal() {
		Endorser result;
		UserAccount userAccount;

		userAccount = LoginService.getPrincipal();
		Assert.notNull(userAccount);
		result = this.endorserByUserAccount(userAccount);
		Assert.notNull(result);

		return result;
	}

	public Endorser endorserByUserAccount(final UserAccount userAccount) {
		Assert.notNull(userAccount);

		Endorser result;

		result = this.endorserRepository.findByUserAccountId(userAccount.getId());

		return result;
	}

	public Endorsement createAndUpdateEndorsemet(final Endorsement endorsement) {
		Assert.notNull(endorsement);

		//TODO: Comprobar que si el sender es un customer, el recipient tiene que ser hw y viceversa

		if (endorsement.getId() == 0)
			endorsement.setMoment(new Date());

		this.endorsementService.save(endorsement);
		return endorsement;

	}

	public Collection<Endorsement> principalEndorsementsSent() {
		return this.endorserRepository.findEndorsementsSentByEndorserId(this.findEndorserByPrincipal().getId());
	}

	public Collection<Endorsement> principalEndorsementsReceived() {
		return this.endorserRepository.findEndorsementsRecipientByEndorserId(this.findEndorserByPrincipal().getId());
	}

	public void deleteEndorsement(final Endorsement endorsement) {

		Assert.notNull(endorsement);

		final Endorser loggedEndorser = this.findEndorserByPrincipal();
		Assert.isTrue((loggedEndorser.getId() == endorsement.getRecipient().getId()) || (loggedEndorser.getId() == endorsement.getSender().getId()));

		this.endorsementService.delete(endorsement);

	}

	public Collection<Endorsement> findEndorsementsRecipientByEndorserId(final Endorser endorser) {
		Assert.notNull(endorser);

		int idPrincipal;
		idPrincipal = LoginService.getPrincipal().getId();
		Assert.isTrue(idPrincipal == endorser.getUserAccount().getId());

		return this.endorserRepository.findEndorsementsRecipientByEndorserId(endorser.getId());
	}

	public Collection<Customer> findRelatedCustomers(final HandyWorker handyWorker) {
		return this.endorserRepository.findRelatedCustomersByHandyWorkerId(handyWorker.getId());
	}

	public Collection<HandyWorker> findRelatedHandyWorkers(final Customer customer) {
		return this.endorserRepository.findRelatedHandyWorkersByCustomerId(customer.getId());
	}
}
