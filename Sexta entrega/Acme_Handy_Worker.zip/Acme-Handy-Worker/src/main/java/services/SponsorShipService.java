/*
 * CustomerService.java
 * 
 * Copyright (C) 2017 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.SponsorShipRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import domain.CreditCard;
import domain.Sponsor;
import domain.SponsorShip;

@Service
@Transactional
public class SponsorShipService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private SponsorShipRepository	sponsorShipRepository;
	@Autowired
	private CreditCardService		creditCardService;
	@Autowired
	private ActorService			actorService;
	@Autowired
	private SponsorService			sponsorService;


	// Constructors -----------------------------------------------------------

	public SponsorShipService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public SponsorShip create() {
		SponsorShip result;

		result = new SponsorShip();

		return result;
	}

	public Collection<SponsorShip> findAll() {
		Collection<SponsorShip> result;

		result = this.sponsorShipRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public SponsorShip findOne(final int sponsorShipId) {
		SponsorShip result;

		result = this.sponsorShipRepository.findOne(sponsorShipId);
		Assert.notNull(result);

		return result;
	}

	public SponsorShip save(final SponsorShip sponsorShip) {
		//comprobar de que el usuario que borra el sponsorship es el principal
		this.checkPrincipalIsSponsor();

		//comprobar que la id pasada como par�metro no es null
		Assert.notNull(sponsorShip);

		SponsorShip result;

		if (sponsorShip.getId() == 0) {
			final Sponsor principal = this.sponsorService.findSponsorByPrincipal();
			sponsorShip.getCreditCard().setActor(principal);
			sponsorShip.setSponsor(principal);
		}

		CreditCard savedCreditCard;

		savedCreditCard = this.creditCardService.save(sponsorShip.getCreditCard());
		sponsorShip.setCreditCard(savedCreditCard);

		result = this.sponsorShipRepository.save(sponsorShip);
		return result;
	}
	public void delete(final SponsorShip sponsorship) {
		//comprobar de que el usuario que borra el sponsorship es el principal
		this.checkPrincipalIsSponsor();

		//comprobar que el sponsorship pasado como par�metro no es null
		Assert.notNull(sponsorship);

		//comprobar que el sponsor principal sea due�o del sponsorship pasado como par�metro
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		Assert.isTrue(sponsorship.getSponsor().getUserAccount().equals(userAccount));

		this.sponsorShipRepository.delete(sponsorship);

		this.creditCardService.delete(sponsorship.getCreditCard());

	}
	// Other business methods -------------------------------------------------

	protected void checkPrincipalIsSponsor() {
		UserAccount userAccount;
		userAccount = LoginService.getPrincipal();
		final Authority adminAuthority = new Authority();
		adminAuthority.setAuthority("SPONSOR");

		Assert.isTrue(userAccount.getAuthorities().contains(adminAuthority));
	}

	public Collection<SponsorShip> findPrincipalSponsorships() {
		//comprobamos que el principal sea un sponsor
		this.checkPrincipalIsSponsor();

		//Cogemos el principal
		UserAccount principal;
		principal = LoginService.getPrincipal();

		//Collection con todas las sponsorships
		Collection<SponsorShip> sponsorships;
		sponsorships = this.findAll();

		//Lista con las sponsorships a eliminar
		List<SponsorShip> sponsorshipsToBeDeleted;
		sponsorshipsToBeDeleted = new ArrayList<>();

		for (final SponsorShip s : sponsorships)
			if (!s.getSponsor().getUserAccount().equals(principal))
				sponsorshipsToBeDeleted.add(s);

		//Eliminamos las sponsorships que no sean del principal
		sponsorships.removeAll(sponsorshipsToBeDeleted);

		return sponsorships;
	}
}
