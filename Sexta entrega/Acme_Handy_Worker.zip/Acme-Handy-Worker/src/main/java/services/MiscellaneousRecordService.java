
package services;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.MiscellaneousRecordRepository;
import domain.Curriculum;
import domain.HandyWorker;
import domain.MiscellaneousRecord;

@Service
@Transactional
public class MiscellaneousRecordService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private MiscellaneousRecordRepository	miscellaneousRecordRepository;
	@Autowired
	private HandyWorkerService				handyWorkerService;
	@Autowired
	private CurriculumService				curriculumService;
	@Autowired
	private ConfigurationService			configurationService;


	// Constructors -----------------------------------------------------------

	public MiscellaneousRecordService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public MiscellaneousRecord create() {
		MiscellaneousRecord result;

		result = new MiscellaneousRecord();

		return result;
	}

	public Collection<MiscellaneousRecord> findAll() {
		Collection<MiscellaneousRecord> result;

		result = this.miscellaneousRecordRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public MiscellaneousRecord findOne(final int miscellaneousRecordId) {
		MiscellaneousRecord result;

		result = this.miscellaneousRecordRepository.findOne(miscellaneousRecordId);
		Assert.notNull(result);

		return result;
	}

	public MiscellaneousRecord save(final MiscellaneousRecord miscellaneousRecord) {
		Assert.notNull(miscellaneousRecord);

		MiscellaneousRecord result;
		HandyWorker handyWorker;
		Curriculum curriculum;

		handyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();
		curriculum = handyWorker.getCurriculum();
		final Collection<MiscellaneousRecord> curriculums = new HashSet<>(curriculum.getMiscellaneousRecords());
		this.configurationService.checkContainsSpamWord(miscellaneousRecord.getComment());
		this.configurationService.checkContainsSpamWord(miscellaneousRecord.getTitle());
		this.configurationService.checkContainsSpamWord(miscellaneousRecord.getAttachmentLink());
		curriculums.add(miscellaneousRecord);
		curriculum.setMiscellaneousRecords(curriculums);
		result = this.miscellaneousRecordRepository.save(miscellaneousRecord);

		this.curriculumService.save(curriculum);
		return result;
	}

	public void delete(final MiscellaneousRecord miscellaneousRecord) {
		Assert.notNull(miscellaneousRecord);
		Assert.isTrue(miscellaneousRecord.getId() != 0);

		HandyWorker handyWorker;
		Curriculum curriculum;

		handyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();
		curriculum = handyWorker.getCurriculum();
		final Collection<MiscellaneousRecord> curriculums = new HashSet<>(curriculum.getMiscellaneousRecords());
		curriculums.remove(miscellaneousRecord);
		curriculum.setMiscellaneousRecords(curriculums);

		this.miscellaneousRecordRepository.delete(miscellaneousRecord);
		this.curriculumService.save(curriculum);

	}

}
