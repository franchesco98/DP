
package services;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ProfessionalRecordRepository;
import domain.Curriculum;
import domain.HandyWorker;
import domain.ProfessionalRecord;

@Service
@Transactional
public class ProfessionalRecordService {

	// Managed repository -----------------------------------------------------

	@Autowired
	private ProfessionalRecordRepository	professionalRecordRepository;
	@Autowired
	private HandyWorkerService				handyWorkerService;
	@Autowired
	private CurriculumService				curriculumService;
	@Autowired
	private ConfigurationService			configurationService;


	// Constructors -----------------------------------------------------------

	public ProfessionalRecordService() {
		super();
	}

	// Simple CRUD methods ----------------------------------------------------

	public ProfessionalRecord create() {
		ProfessionalRecord result;

		result = new ProfessionalRecord();

		return result;
	}

	public Collection<ProfessionalRecord> findAll() {
		Collection<ProfessionalRecord> result;

		result = this.professionalRecordRepository.findAll();
		Assert.notNull(result);

		return result;
	}

	public ProfessionalRecord findOne(final int professionalRecordId) {
		ProfessionalRecord result;

		result = this.professionalRecordRepository.findOne(professionalRecordId);
		Assert.notNull(result);

		return result;
	}

	public ProfessionalRecord save(final ProfessionalRecord professionalRecord) {
		Assert.notNull(professionalRecord);

		ProfessionalRecord result;
		HandyWorker handyWorker;
		Curriculum curriculum;

		handyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();
		curriculum = handyWorker.getCurriculum();
		final Collection<ProfessionalRecord> curriculums = new HashSet<>(curriculum.getProfessionalRecords());
		Assert.isTrue(professionalRecord.getStartDate().before(professionalRecord.getEndDate()));
		this.configurationService.checkContainsSpamWord(professionalRecord.getAttachmentLink());
		this.configurationService.checkContainsSpamWord(professionalRecord.getComment());
		this.configurationService.checkContainsSpamWord(professionalRecord.getCompanyName());
		this.configurationService.checkContainsSpamWord(professionalRecord.getRolePlayed());

		curriculums.add(professionalRecord);
		curriculum.setProfessionalRecords(curriculums);
		result = this.professionalRecordRepository.save(professionalRecord);

		this.curriculumService.save(curriculum);
		return result;
	}

	public void delete(final ProfessionalRecord professionalRecord) {
		Assert.notNull(professionalRecord);
		Assert.isTrue(professionalRecord.getId() != 0);

		HandyWorker handyWorker;
		Curriculum curriculum;

		handyWorker = this.handyWorkerService.findHandyWorkerByPrincipal();
		curriculum = handyWorker.getCurriculum();
		final Collection<ProfessionalRecord> curriculums = new HashSet<>(curriculum.getProfessionalRecords());

		curriculums.remove(professionalRecord);
		curriculum.setProfessionalRecords(curriculums);

		this.professionalRecordRepository.delete(professionalRecord);
		this.curriculumService.save(curriculum);

	}

}
