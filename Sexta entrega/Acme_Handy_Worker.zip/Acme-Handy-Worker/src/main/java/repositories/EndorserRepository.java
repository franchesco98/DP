
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Customer;
import domain.Endorsement;
import domain.Endorser;
import domain.HandyWorker;

@Repository
public interface EndorserRepository extends JpaRepository<Endorser, Integer> {

	@Query("select e from Endorsement e where e.recipient.id = ?1 or e.sender.id = ?1")
	Collection<Endorsement> findEndorsementsByEndorserId(int endorserId);

	@Query("select e from Endorsement e where e.sender.id = ?1")
	Collection<Endorsement> findEndorsementsSentByEndorserId(int endorserId);

	@Query("select e from Endorsement e where e.recipient.id = ?1")
	Collection<Endorsement> findEndorsementsRecipientByEndorserId(int endorserId);

	@Query("select e from Endorser e where e.userAccount.id = ?1")
	Endorser findByUserAccountId(int UserAccountId);

	@Query("select distinct c from Customer c, Application a where a.status = 'ACCEPTED' and a.fixUpTask.customer.id=c.id and a.handyWorker.id = ?1")
	Collection<Customer> findRelatedCustomersByHandyWorkerId(int handyWorkerId);

	@Query("select distinct a.handyWorker from Application a, Customer c, FixUpTask f where a.status = 'ACCEPTED' and a.fixUpTask.customer.id=c.id and c.id = ?1")
	Collection<HandyWorker> findRelatedHandyWorkersByCustomerId(int customerId);
}
