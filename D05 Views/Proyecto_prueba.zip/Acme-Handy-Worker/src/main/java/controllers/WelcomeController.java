/*
 * WelcomeController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ApplicationService;
import services.ConfigurationService;
import services.CustomerService;
import services.FixUpTaskService;
import services.HandyWorkerService;
import services.PhaseService;
import domain.Application;
import domain.Configuration;
import domain.FixUpTask;
import domain.HandyWorker;
import domain.Phase;

@Controller
@RequestMapping("/welcome")
public class WelcomeController extends AbstractController {

	//Services
	@Autowired
	ConfigurationService	configurationService;
	@Autowired
	FixUpTaskService		fixUpTaskService;
	@Autowired
	CustomerService			customerService;
	@Autowired
	HandyWorkerService		handyService;
	@Autowired
	PhaseService			phaseService;
	@Autowired
	ApplicationService		applicationService;


	// Constructors -----------------------------------------------------------

	public WelcomeController() {
		super();
	}

	// Index ------------------------------------------------------------------		

	@RequestMapping(value = "/index")
	public ModelAndView index(@RequestParam(required = false, defaultValue = "John Doe") final String name) {
		ModelAndView result;
		SimpleDateFormat formatter;
		String moment;
		final Application app = this.applicationService.findOne(17608);
		final Collection<String> reasons = new ArrayList<>();
		final Collection<Application> allApllications = this.applicationService.findAll();

		formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		moment = formatter.format(new Date());

		result = new ModelAndView("welcome/index");
		result.addObject("name", name);
		result.addObject("moment", moment);

		final Configuration configuration = (Configuration) this.configurationService.findAll().toArray()[0];

		result.addObject("nameSystem", configuration.getNameSystem());
		result.addObject("confi", configuration);

		final List<FixUpTask> fixUpTasks = new ArrayList<>(this.fixUpTaskService.findAll());
		result.addObject("fixUpTasks", fixUpTasks);

		final FixUpTask fixUpTask = this.fixUpTaskService.findOne(17582);
		result.addObject("fixUpTask", fixUpTask);

		final HandyWorker customer = this.handyService.findOne(17565);
		result.addObject("customer", customer);

		final boolean aux = true;
		result.addObject("isHandy", aux);
		result.addObject("idZero", !aux);
		result.addObject("idNoZero", aux);
		result.addObject("toShow", aux);

		final Collection<Phase> phases = this.phaseService.findAll();
		result.addObject("phases", phases);

		result.addObject("application", app);

		reasons.add("ACCEPTED");
		reasons.add("REJECTED");

		result.addObject("possibleStatus", reasons);

		result.addObject("applications", allApllications);

		return result;

	}
}
