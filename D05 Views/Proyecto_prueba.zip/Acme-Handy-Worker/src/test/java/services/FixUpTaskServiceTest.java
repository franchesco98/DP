
package services;

import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Category;
import domain.Customer;
import domain.FixUpTask;
import domain.Warranty;

@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
public class FixUpTaskServiceTest extends AbstractTest {

	@Autowired
	private FixUpTaskService	fixUpTaskService;
	@Autowired
	private CategoryService		categoryService;
	@Autowired
	private CustomerService		customerService;
	@Autowired
	private WarrantyService		warrantyService;


	@SuppressWarnings("deprecation")
	@Test
	public void testSaveFixUpTask() {
		super.authenticate("customer1");
		final Date d = new Date(2018 - 1900, 11, 1);
		final Date moment = new Date(2018 - 1900, 10, 2);
		final Date d2 = new Date(2018 - 1900, 12, 2);
		final FixUpTask fixUpTask;
		FixUpTask saved;
		Collection<FixUpTask> fixUpTasks;
		final Customer customer = this.customerService.findCustomerByPrincipal();
		final Category category = this.categoryService.findOne(17537);
		final Warranty warranty = this.warrantyService.findOne(17546);

		fixUpTask = this.fixUpTaskService.create();
		fixUpTask.setAddress("Calle Zarzavieja n2");
		fixUpTask.setTicker("181938-328dsa");
		fixUpTask.setStartTime(d);
		fixUpTask.setMoment(moment);
		fixUpTask.setEndTime(d2);
		fixUpTask.setDescription("Tpm");
		fixUpTask.setCategory(category);
		fixUpTask.setCustomer(customer);
		fixUpTask.setMaxPrice(23.);
		fixUpTask.setWarranty(warranty);

		saved = this.fixUpTaskService.save(fixUpTask);
		fixUpTasks = this.fixUpTaskService.findAll();
		Assert.isTrue(fixUpTasks.contains(saved));
	}
}
